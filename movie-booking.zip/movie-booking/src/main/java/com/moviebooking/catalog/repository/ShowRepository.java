package com.moviebooking.catalog.repository;

import com.moviebooking.catalog.model.AudioLanguage;
import com.moviebooking.catalog.model.MovieFormat;
import com.moviebooking.catalog.model.Show;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface ShowRepository extends JpaRepository<Show, Long> {

    @Query("SELECT DISTINCT s.language FROM Show s WHERE s.movie.id = :movieId AND s.screen.theatre.city.id = :cityId AND s.startTime >= CURRENT_TIMESTAMP")
    List<AudioLanguage> findAvailableLanguagesForMovieAndCity(@Param("movieId") Long movieId, @Param("cityId") Long cityId);

    @Query("SELECT DISTINCT s.format FROM Show s WHERE s.movie.id = :movieId AND s.screen.theatre.city.id = :cityId AND s.startTime >= CURRENT_TIMESTAMP")
    List<MovieFormat> findAvailableFormatsForMovieAndCity(@Param("movieId") Long movieId, @Param("cityId") Long cityId);

    @Query("SELECT s FROM Show s WHERE s.movie.id = :movieId AND s.screen.theatre.city.id = :cityId AND s.startTime BETWEEN :startTime AND :endTime ORDER BY s.screen.theatre.name, s.startTime")
    List<Show> findShowsForMovieAndCityInDateRange(
            @Param("movieId") Long movieId,
            @Param("cityId") Long cityId,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime
    );
}