package com.moviebooking.catalog.repository;

import com.moviebooking.catalog.model.Screen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ScreenRepository extends JpaRepository<Screen, Long> {
    
    // Find all screens belonging to a specific theatre
    List<Screen> findByTheatreId(Long theatreId);
}