package com.moviebooking.catalog.service;

import com.moviebooking.catalog.dto.*;
import com.moviebooking.catalog.model.*;
import com.moviebooking.catalog.repository.*;
import com.moviebooking.common.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class CatalogService {

    private final CityRepository cityRepository;
    private final TheatreRepository theatreRepository;
    private final MovieRepository movieRepository;
    private final ShowRepository showRepository;

    public CatalogService(CityRepository cityRepository,
                          TheatreRepository theatreRepository,
                          MovieRepository movieRepository,
                          ShowRepository showRepository) {
        this.cityRepository = cityRepository;
        this.theatreRepository = theatreRepository;
        this.movieRepository = movieRepository;
        this.showRepository = showRepository;
    }

    public List<CityResponse> getAllCities() {
        return cityRepository.findAllByOrderByNameAsc()
                .stream()
                .map(city -> new CityResponse(city.getId(), city.getName(), city.getState()))
                .collect(Collectors.toList());
    }

    public List<MovieSummaryResponse> getMoviesRunningInCity(Long cityId) {
        validateCityExists(cityId);
        List<Movie> movies = movieRepository.findMoviesRunningInCity(cityId);

        return movies.stream().map(movie -> {
            List<String> langs = showRepository.findAvailableLanguagesForMovieAndCity(movie.getId(), cityId)
                    .stream().map(Enum::name).collect(Collectors.toList());
            List<String> formats = showRepository.findAvailableFormatsForMovieAndCity(movie.getId(), cityId)
                    .stream().map(MovieFormat::getValue).collect(Collectors.toList());

            return new MovieSummaryResponse(
                    movie.getId(),
                    movie.getTitle(),
                    movie.getPosterUrl(),
                    movie.getDurationMinutes(),
                    movie.getCbfcRating(),
                    langs,
                    formats
            );
        }).collect(Collectors.toList());
    }

    public MovieDetailResponse getMovieDetails(Long movieId, Long cityId) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with ID: " + movieId));

        List<String> langs = showRepository.findAvailableLanguagesForMovieAndCity(movieId, cityId)
                .stream().map(Enum::name).collect(Collectors.toList());

        List<String> formats = showRepository.findAvailableFormatsForMovieAndCity(movieId, cityId)
                .stream().map(MovieFormat::getValue).collect(Collectors.toList());

        List<Show> shows = showRepository.findShowsForMovieAndCityInDateRange(
                movieId, cityId, LocalDateTime.now(), LocalDateTime.now().plusDays(7)
        );

        boolean hasCaptions = shows.stream().anyMatch(Show::getHasCaptions);

        return new MovieDetailResponse(
                movie.getId(),
                movie.getTitle(),
                movie.getDescription(),
                movie.getCastMembers(),
                movie.getDirector(),
                movie.getDurationMinutes(),
                movie.getCbfcRating(),
                movie.getPosterUrl(),
                movie.getBannerUrl(),
                movie.getReleaseDate(),
                langs,
                formats,
                hasCaptions
        );
    }

    public List<TheatreShowResponse> getShowsForMovieAndDate(Long movieId, Long cityId, LocalDate date) {
        validateCityExists(cityId);

        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);

        List<Show> shows = showRepository.findShowsForMovieAndCityInDateRange(movieId, cityId, startOfDay, endOfDay);

        // Group shows by Theatre
        Map<Theatre, List<Show>> theatreShowMap = shows.stream()
                .collect(Collectors.groupingBy(show -> show.getScreen().getTheatre()));

        List<TheatreShowResponse> response = new ArrayList<>();

        for (Map.Entry<Theatre, List<Show>> entry : theatreShowMap.entrySet()) {
            Theatre theatre = entry.getKey();
            List<ShowTimeResponse> showTimes = entry.getValue().stream()
                    .map(show -> new ShowTimeResponse(
                            show.getId(),
                            show.getScreen().getName(),
                            show.getStartTime(),
                            show.getLanguage().name(),
                            show.getFormat().getValue(),
                            show.getHasCaptions(),
                            show.getBasePrice()
                    )).collect(Collectors.toList());

            response.add(new TheatreShowResponse(
                    theatre.getId(),
                    theatre.getName(),
                    theatre.getAddress(),
                    showTimes
            ));
        }

        return response;
    }

    private void validateCityExists(Long cityId) {
        if (!cityRepository.existsById(cityId)) {
            throw new ResourceNotFoundException("City not found with ID: " + cityId);
        }
    }
}