package com.moviebooking.catalog.repository;

import com.moviebooking.catalog.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MovieRepository extends JpaRepository<Movie, Long> {

    @Query("SELECT DISTINCT s.movie FROM Show s WHERE s.screen.theatre.city.id = :cityId AND s.startTime >= CURRENT_TIMESTAMP")
    List<Movie> findMoviesRunningInCity(@Param("cityId") Long cityId);
}