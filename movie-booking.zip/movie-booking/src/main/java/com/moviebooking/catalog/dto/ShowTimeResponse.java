package com.moviebooking.catalog.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class ShowTimeResponse {
    private Long showId;
    private String screenName;
    private LocalDateTime startTime;
    private String language;
    private String format;
    private Boolean hasCaptions;
    private BigDecimal price;
}