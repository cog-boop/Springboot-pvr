package com.moviebooking.booking.service;

import com.moviebooking.auth.entity.User;
import com.moviebooking.auth.repository.UserRepository;
import com.moviebooking.booking.dto.BookingDTOs.*;
import com.moviebooking.booking.model.Booking;
import com.moviebooking.booking.model.BookingStatus;
import com.moviebooking.booking.model.SeatStatus;
import com.moviebooking.booking.model.ShowSeat;
import com.moviebooking.booking.repository.BookingRepository;
import com.moviebooking.booking.repository.ShowSeatRepository;
import com.moviebooking.catalog.model.Show;
import com.moviebooking.catalog.repository.ShowRepository;
import com.moviebooking.common.exception.BusinessException;
import com.moviebooking.common.exception.ResourceNotFoundException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class BookingService {

    // Fixed seats-per-row used to lay out a screen's totalSeats into a grid.
    // A future iteration can swap this for the per-screen custom layout designer
    // already stubbed in the admin panel; this keeps booking core self-contained.
    private static final int SEATS_PER_ROW = 10;
    private static final int MAX_SEATS_PER_BOOKING = 10;
    private static final int HOLD_MINUTES = 10;

    private final ShowRepository showRepository;
    private final ShowSeatRepository showSeatRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;

    public BookingService(ShowRepository showRepository,
                           ShowSeatRepository showSeatRepository,
                           BookingRepository bookingRepository,
                           UserRepository userRepository) {
        this.showRepository = showRepository;
        this.showSeatRepository = showSeatRepository;
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
    }

    private User currentUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmailAndIsDeletedFalse(email)
                .orElseThrow(() -> new ResourceNotFoundException("Authenticated user not found"));
    }

    // "A10" -> "A", "AA3" -> "AA". The alphabetic row prefix of a seat code.
    private static String rowPart(String code) {
        int i = 0;
        while (i < code.length() && Character.isLetter(code.charAt(i))) i++;
        return code.substring(0, i);
    }

    // "A10" -> 10. The numeric seat index within the row. Defaults to 0 if absent.
    private static int numberPart(String code) {
        int i = 0;
        while (i < code.length() && Character.isLetter(code.charAt(i))) i++;
        try {
            return Integer.parseInt(code.substring(i));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private List<String> generateSeatCodes(int totalSeats) {
        List<String> codes = new ArrayList<>();
        int seatsLeft = totalSeats;
        int rowIndex = 0;
        while (seatsLeft > 0) {
            char rowLabel = (char) ('A' + rowIndex);
            int seatsInThisRow = Math.min(SEATS_PER_ROW, seatsLeft);
            for (int i = 1; i <= seatsInThisRow; i++) {
                codes.add("" + rowLabel + i);
            }
            seatsLeft -= seatsInThisRow;
            rowIndex++;
        }
        return codes;
    }

    // Creates the show_seats rows the first time a show's seat map is touched.
    // Safe under concurrency: if two requests race, the loser's insert hits the
    // (show_id, seat_code) unique constraint and is simply ignored.
    @Transactional
    protected Show ensureSeatsInitialized(Long showId) {
        Show show = showRepository.findById(showId)
                .orElseThrow(() -> new ResourceNotFoundException("Show not found with ID: " + showId));

        if (showSeatRepository.countByShowId(showId) == 0) {
            List<String> codes = generateSeatCodes(show.getScreen().getTotalSeats());
            List<ShowSeat> seats = codes.stream().map(code -> {
                ShowSeat s = new ShowSeat();
                s.setShow(show);
                s.setSeatCode(code);
                s.setStatus(SeatStatus.AVAILABLE);
                return s;
            }).collect(Collectors.toList());
            try {
                showSeatRepository.saveAll(seats);
            } catch (DataIntegrityViolationException ignored) {
                // Another request initialized the same show concurrently - fine.
            }
        }
        return show;
    }

    @Transactional
    public SeatMapResponse getSeatMap(Long showId) {
        Show show = ensureSeatsInitialized(showId);
        Long myUserId = currentUser().getId();
        expireStaleHolds();

        List<ShowSeat> seats = showSeatRepository.findByShowId(showId);
        List<SeatInfo> seatInfos = seats.stream()
                .sorted(java.util.Comparator
                        .comparing((ShowSeat s) -> rowPart(s.getSeatCode()))
                        .thenComparingInt(s -> numberPart(s.getSeatCode())))
                .map(s -> new SeatInfo(
                        s.getSeatCode(),
                        s.getStatus().name(),
                        s.getStatus() == SeatStatus.HELD && myUserId.equals(s.getHeldByUserId())
                ))
                .collect(Collectors.toList());

        int totalSeats = show.getScreen().getTotalSeats();
        int rows = (int) Math.ceil(totalSeats / (double) SEATS_PER_ROW);

        return new SeatMapResponse(showId, rows, SEATS_PER_ROW, totalSeats, show.getBasePrice(), seatInfos);
    }

    // All-or-nothing: either every requested seat gets held, or none do.
    @Transactional
    public BookingResponse holdSeats(HoldSeatsRequest req) {
        if (req.seatCodes() == null || req.seatCodes().isEmpty()) {
            throw new BusinessException("Select at least one seat.");
        }
        Set<String> uniqueCodes = new LinkedHashSet<>(req.seatCodes());
        if (uniqueCodes.size() > MAX_SEATS_PER_BOOKING) {
            throw new BusinessException("A maximum of " + MAX_SEATS_PER_BOOKING + " seats can be booked at once.");
        }

        Show show = ensureSeatsInitialized(req.showId());
        User user = currentUser();
        expireStaleHolds();

        List<String> codesList = new ArrayList<>(uniqueCodes);
        List<ShowSeat> lockedSeats = showSeatRepository.findForUpdate(req.showId(), codesList);

        if (lockedSeats.size() != codesList.size()) {
            throw new BusinessException("One or more selected seats do not exist on this screen.");
        }

        LocalDateTime now = LocalDateTime.now();
        List<String> unavailable = lockedSeats.stream()
                .filter(s -> s.getStatus() == SeatStatus.BOOKED
                        || (s.getStatus() == SeatStatus.HELD
                            && s.getHoldExpiresAt() != null
                            && s.getHoldExpiresAt().isAfter(now)
                            && !user.getId().equals(s.getHeldByUserId())))
                .map(ShowSeat::getSeatCode)
                .collect(Collectors.toList());

        if (!unavailable.isEmpty()) {
            throw new BusinessException("These seats are no longer available: " + String.join(", ", unavailable));
        }

        LocalDateTime expiry = now.plusMinutes(HOLD_MINUTES);

        Booking booking = new Booking();
        booking.setShow(show);
        booking.setUser(user);
        booking.setSeatCodes(String.join(",", codesList));
        booking.setNumberOfSeats(codesList.size());
        booking.setTotalAmount(show.getBasePrice().multiply(BigDecimal.valueOf(codesList.size())));
        booking.setStatus(BookingStatus.PENDING_PAYMENT);
        booking.setTransactionId(UUID.randomUUID().toString());
        booking.setHoldExpiresAt(expiry);
        Booking savedBooking = bookingRepository.save(booking);

        for (ShowSeat s : lockedSeats) {
            s.setStatus(SeatStatus.HELD);
            s.setHeldByUserId(user.getId());
            s.setHoldExpiresAt(expiry);
            s.setBookingId(savedBooking.getId());
        }
        showSeatRepository.saveAll(lockedSeats);

        return toBookingResponse(savedBooking, codesList);
    }

    @Transactional
    public BookingResponse getBooking(Long bookingId) {
        User user = currentUser();
        Booking booking = bookingRepository.findByIdAndUserId(bookingId, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + bookingId));
        return toBookingResponse(booking, List.of(booking.getSeatCodes().split(",")));
    }

    // User voluntarily backs out before paying - release seats immediately
    // instead of waiting for the hold to expire.
    @Transactional
    public void cancelBooking(Long bookingId) {
        User user = currentUser();
        Booking booking = bookingRepository.findByIdAndUserId(bookingId, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + bookingId));

        if (booking.getStatus() != BookingStatus.PENDING_PAYMENT) {
            throw new BusinessException("Only a pending booking can be cancelled.");
        }

        List<String> codes = List.of(booking.getSeatCodes().split(","));
        List<ShowSeat> seats = showSeatRepository.findForUpdate(booking.getShow().getId(), codes);
        for (ShowSeat s : seats) {
            if (booking.getId().equals(s.getBookingId())) {
                s.setStatus(SeatStatus.AVAILABLE);
                s.setHeldByUserId(null);
                s.setHoldExpiresAt(null);
                s.setBookingId(null);
            }
        }
        showSeatRepository.saveAll(seats);

        booking.setStatus(BookingStatus.CANCELLED);
        bookingRepository.save(booking);
    }

    // Flips any hold whose 10-minute window has lapsed back to AVAILABLE, and
    // marks the associated booking EXPIRED. Called opportunistically on every
    // seat-map/hold request so availability is always self-healing, in addition
    // to the scheduled sweep in BookingMaintenanceScheduler.
    @Transactional
    public void expireStaleHolds() {
        LocalDateTime now = LocalDateTime.now();
        List<ShowSeat> expired = showSeatRepository.findExpiredHoldsForUpdate(now);
        if (expired.isEmpty()) return;

        Set<Long> bookingIds = new LinkedHashSet<>();
        for (ShowSeat s : expired) {
            if (s.getBookingId() != null) bookingIds.add(s.getBookingId());
            s.setStatus(SeatStatus.AVAILABLE);
            s.setHeldByUserId(null);
            s.setHoldExpiresAt(null);
            s.setBookingId(null);
        }
        showSeatRepository.saveAll(expired);

        for (Long bId : bookingIds) {
            bookingRepository.findById(bId).ifPresent(b -> {
                if (b.getStatus() == BookingStatus.PENDING_PAYMENT) {
                    b.setStatus(BookingStatus.EXPIRED);
                    bookingRepository.save(b);
                }
            });
        }
    }

    private BookingResponse toBookingResponse(Booking b, List<String> seatCodes) {
        Show show = b.getShow();
        return new BookingResponse(
                b.getId(),
                b.getTransactionId(),
                show.getId(),
                show.getMovie().getTitle(),
                show.getScreen().getTheatre().getName(),
                show.getScreen().getName(),
                show.getStartTime(),
                seatCodes,
                b.getNumberOfSeats(),
                b.getTotalAmount(),
                b.getStatus(),
                b.getHoldExpiresAt()
        );
    }
}
