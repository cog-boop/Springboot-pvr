package com.moviebooking.booking.repository;

import com.moviebooking.booking.model.ShowSeat;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface ShowSeatRepository extends JpaRepository<ShowSeat, Long> {

    long countByShowId(Long showId);

    List<ShowSeat> findByShowId(Long showId);

    // Row-level lock: two concurrent hold requests for overlapping seats will
    // serialize here instead of both succeeding.
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select s from ShowSeat s where s.show.id = :showId and s.seatCode in :seatCodes")
    List<ShowSeat> findForUpdate(@Param("showId") Long showId, @Param("seatCodes") List<String> seatCodes);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select s from ShowSeat s where s.status = 'HELD' and s.holdExpiresAt < :now")
    List<ShowSeat> findExpiredHoldsForUpdate(@Param("now") LocalDateTime now);
}
