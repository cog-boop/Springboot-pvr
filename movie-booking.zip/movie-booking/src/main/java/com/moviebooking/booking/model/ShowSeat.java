package com.moviebooking.booking.model;

import com.moviebooking.catalog.model.Show;
import com.moviebooking.common.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

// One row per physical seat per show. Generated lazily the first time a show's
// seat map is requested (see BookingService#ensureSeatsInitialized).
@Entity
@Table(name = "show_seats", uniqueConstraints = @UniqueConstraint(columnNames = {"show_id", "seat_code"}))
@Getter
@Setter
@NoArgsConstructor
public class ShowSeat extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "show_id", nullable = false)
    private Show show;

    @Column(name = "seat_code", nullable = false, length = 10)
    private String seatCode; // e.g. "A1", "B10"

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private SeatStatus status = SeatStatus.AVAILABLE;

    // Who currently holds this seat (during the 10-minute payment window)
    private Long heldByUserId;

    private LocalDateTime holdExpiresAt;

    // Which booking this seat is attached to (HELD or BOOKED); null when AVAILABLE
    private Long bookingId;
}
