package com.moviebooking.booking.dto;

import com.moviebooking.booking.model.BookingStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class BookingDTOs {

    // One seat's current state in the seat map grid
    public record SeatInfo(
        String seatCode,
        String status,     // AVAILABLE | HELD | BOOKED
        Boolean heldByMe
    ) {}

    public record SeatMapResponse(
        Long showId,
        Integer rows,
        Integer seatsPerRow,
        Integer totalSeats,
        BigDecimal pricePerSeat,
        List<SeatInfo> seats
    ) {}

    public record HoldSeatsRequest(
        Long showId,
        List<String> seatCodes
    ) {}

    public record BookingResponse(
        Long bookingId,
        String transactionId,
        Long showId,
        String movieTitle,
        String theatreName,
        String screenName,
        LocalDateTime showStartTime,
        List<String> seatCodes,
        Integer numberOfSeats,
        BigDecimal totalAmount,
        BookingStatus status,
        LocalDateTime holdExpiresAt
    ) {}
}
