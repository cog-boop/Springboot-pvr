package com.moviebooking.admin.service;

import com.moviebooking.admin.dto.AdminDTOs.*;
import com.moviebooking.auth.entity.User;
import com.moviebooking.auth.repository.UserRepository;
import com.moviebooking.catalog.model.*;
import com.moviebooking.catalog.repository.*;
import com.moviebooking.common.constants.Role;
import com.moviebooking.common.constants.UserStatus;
import com.moviebooking.common.exception.BusinessException;
import com.moviebooking.common.exception.ResourceNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class AdminService {

    private final CityRepository cityRepository;
    private final MovieRepository movieRepository;
    private final TheatreRepository theatreRepository;
    private final ScreenRepository screenRepository;
    private final ShowRepository showRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminService(CityRepository cityRepository,
                        MovieRepository movieRepository,
                        TheatreRepository theatreRepository,
                        ScreenRepository screenRepository,
                        ShowRepository showRepository,
                        UserRepository userRepository,
                        PasswordEncoder passwordEncoder) {
        this.cityRepository = cityRepository;
        this.movieRepository = movieRepository;
        this.theatreRepository = theatreRepository;
        this.screenRepository = screenRepository;
        this.showRepository = showRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // --- CITIES ---
    public City createCity(CityRequest req) {
        City city = new City();
        city.setName(req.name());
        city.setState(req.state());
        return cityRepository.save(city);
    }

    public List<City> getAllCities() {
        return cityRepository.findAllByOrderByNameAsc();
    }

    public void deleteCity(Long id) {
        if (!cityRepository.existsById(id)) {
            throw new ResourceNotFoundException("City not found with ID: " + id);
        }
        cityRepository.deleteById(id);
    }

    // --- MOVIES ---
    public Movie createMovie(MovieRequest req) {
        Movie movie = new Movie();
        movie.setTitle(req.title());
        movie.setDescription(req.description());
        movie.setCastMembers(req.castMembers());
        movie.setDirector(req.director());
        movie.setDurationMinutes(req.durationMinutes());
        movie.setCbfcRating(req.cbfcRating());
        movie.setPosterUrl(req.posterUrl());
        movie.setBannerUrl(req.bannerUrl());
        movie.setReleaseDate(req.releaseDate());
        return movieRepository.save(movie);
    }

    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    public void deleteMovie(Long id) {
        if (!movieRepository.existsById(id)) {
            throw new ResourceNotFoundException("Movie not found with ID: " + id);
        }
        movieRepository.deleteById(id);
    }

    // --- THEATRES & SCREENS ---
    public TheatreResponse createTheatre(TheatreRequest req) {
        City city = cityRepository.findById(req.cityId())
                .orElseThrow(() -> new ResourceNotFoundException("City not found with ID: " + req.cityId()));

        Theatre theatre = new Theatre();
        theatre.setName(req.name());
        theatre.setAddress(req.address());
        theatre.setCity(city);
        Theatre saved = theatreRepository.save(theatre);
        return mapToTheatreResponse(saved);
    }

    public List<TheatreResponse> getAllTheatres() {
        return theatreRepository.findAll().stream()
                .map(this::mapToTheatreResponse)
                .collect(Collectors.toList());
    }

    public List<TheatreResponse> getTheatresByCity(Long cityId) {
        return theatreRepository.findByCityId(cityId).stream()
                .map(this::mapToTheatreResponse)
                .collect(Collectors.toList());
    }

    public Screen createScreen(Long theatreId, ScreenRequest req) {
        Theatre theatre = theatreRepository.findById(theatreId)
                .orElseThrow(() -> new ResourceNotFoundException("Theatre not found with ID: " + theatreId));

        Screen screen = new Screen();
        screen.setName(req.name());
        screen.setTotalSeats(req.totalSeats());
        screen.setTheatre(theatre);
        return screenRepository.save(screen);
    }

    public List<ScreenResponse> getScreensByTheatre(Long theatreId) {
        return screenRepository.findByTheatreId(theatreId).stream()
                .map(s -> new ScreenResponse(s.getId(), s.getName(), s.getTotalSeats()))
                .collect(Collectors.toList());
    }

    // Persists a custom seat layout for a screen. The matrix uses 1 = seat and
    // 0 = pathway; totalSeats is recomputed from the active (1) cells so the
    // rest of the system stays consistent with the designer.
    public ScreenLayoutResponse updateScreenLayout(Long screenId, SeatLayoutRequest req) {
        Screen screen = screenRepository.findById(screenId)
                .orElseThrow(() -> new ResourceNotFoundException("Screen not found with ID: " + screenId));

        if (req.matrix() == null || req.matrix().isEmpty()) {
            throw new BusinessException("Seat layout matrix cannot be empty.");
        }

        int activeSeats = 0;
        StringBuilder rowsJson = new StringBuilder();
        for (int r = 0; r < req.matrix().size(); r++) {
            List<Integer> row = req.matrix().get(r);
            if (r > 0) rowsJson.append(",");
            rowsJson.append("[");
            for (int c = 0; c < row.size(); c++) {
                int v = (row.get(c) != null && row.get(c) == 1) ? 1 : 0;
                if (v == 1) activeSeats++;
                if (c > 0) rowsJson.append(",");
                rowsJson.append(v);
            }
            rowsJson.append("]");
        }

        if (activeSeats == 0) {
            throw new BusinessException("A screen must have at least one active seat.");
        }

        int rows = req.rows() != null ? req.rows() : req.matrix().size();
        int cols = req.cols() != null ? req.cols()
                : req.matrix().stream().mapToInt(List::size).max().orElse(0);

        String json = "{\"rows\":" + rows + ",\"cols\":" + cols
                + ",\"matrix\":[" + rowsJson + "]}";

        screen.setLayoutJson(json);
        screen.setTotalSeats(activeSeats);
        Screen saved = screenRepository.save(screen);
        return new ScreenLayoutResponse(saved.getId(), saved.getName(), saved.getTotalSeats(), saved.getLayoutJson());
    }

    // --- THEATRE OWNER ASSIGNMENT ---
    // Admin-provisioned: creates a THEATRE_OWNER user (pre-verified & active,
    // no OTP flow needed since admin vouches for identity) and links it to
    // exactly one theatre. Enforces one-owner-per-theatre.
    public TheatreResponse assignOwner(Long theatreId, AssignOwnerRequest req) {
        Theatre theatre = theatreRepository.findById(theatreId)
                .orElseThrow(() -> new ResourceNotFoundException("Theatre not found with ID: " + theatreId));

        if (theatre.getOwner() != null) {
            throw new BusinessException("This theatre already has an owner assigned. Unassign the current owner first.");
        }
        if (userRepository.existsByEmailAndIsDeletedFalse(req.email())) {
            throw new BusinessException("A user with this email already exists.");
        }

        User owner = new User();
        owner.setName(req.name());
        owner.setEmail(req.email());
        owner.setPasswordHash(passwordEncoder.encode(req.password()));
        owner.setRole(Role.THEATRE_OWNER);
        owner.setIsEmailVerified(true);
        owner.setStatus(UserStatus.ACTIVE);
        User savedOwner = userRepository.save(owner);

        theatre.setOwner(savedOwner);
        Theatre saved = theatreRepository.save(theatre);
        return mapToTheatreResponse(saved);
    }

    public TheatreResponse unassignOwner(Long theatreId) {
        Theatre theatre = theatreRepository.findById(theatreId)
                .orElseThrow(() -> new ResourceNotFoundException("Theatre not found with ID: " + theatreId));

        theatre.setOwner(null);
        Theatre saved = theatreRepository.save(theatre);
        return mapToTheatreResponse(saved);
    }

    // Helper mapping method to keep responses clean and cycle-free
    private TheatreResponse mapToTheatreResponse(Theatre t) {
        List<ScreenResponse> screens = (t.getScreens() == null) ? List.of() :
                t.getScreens().stream()
                        .map(s -> new ScreenResponse(s.getId(), s.getName(), s.getTotalSeats()))
                        .collect(Collectors.toList());

        String cityName = t.getCity() != null ? t.getCity().getName() : "";
        Long cityId = t.getCity() != null ? t.getCity().getId() : null;

        Long ownerId = t.getOwner() != null ? t.getOwner().getId() : null;
        String ownerName = t.getOwner() != null ? t.getOwner().getName() : null;
        String ownerEmail = t.getOwner() != null ? t.getOwner().getEmail() : null;

        return new TheatreResponse(t.getId(), t.getName(), t.getAddress(), cityId, cityName, screens,
                ownerId, ownerName, ownerEmail);
    }

    // --- SHOWS ---
    public Show scheduleShow(ShowRequest req) {
        Screen screen = screenRepository.findById(req.screenId())
                .orElseThrow(() -> new ResourceNotFoundException("Screen not found with ID: " + req.screenId()));

        Movie movie = movieRepository.findById(req.movieId())
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with ID: " + req.movieId()));

        Show show = new Show();
        show.setScreen(screen);
        show.setMovie(movie);
        show.setStartTime(req.startTime());
        show.setLanguage(req.language());
        show.setFormat(req.format());
        show.setHasCaptions(req.hasCaptions() != null ? req.hasCaptions() : false);
        show.setBasePrice(req.basePrice());

        return showRepository.save(show);
    }

    public List<ShowResponse> getAllShows() {
        return showRepository.findAll().stream()
                .map(this::mapToShowResponse)
                .collect(Collectors.toList());
    }

    // Touching movie/screen/theatre here (inside the @Transactional service)
    // forces the LAZY proxies to load while the Hibernate session is still open.
    private ShowResponse mapToShowResponse(Show s) {
        Movie movie = s.getMovie();
        Screen screen = s.getScreen();
        Theatre theatre = (screen != null) ? screen.getTheatre() : null;
        return new ShowResponse(
                s.getId(),
                movie != null ? movie.getId() : null,
                movie != null ? movie.getTitle() : null,
                screen != null ? screen.getId() : null,
                screen != null ? screen.getName() : null,
                theatre != null ? theatre.getName() : null,
                s.getStartTime(),
                s.getLanguage() != null ? s.getLanguage().name() : null,
                s.getFormat() != null ? s.getFormat().name() : null,
                s.getHasCaptions(),
                s.getBasePrice()
        );
    }

    public void cancelShow(Long id) {
        if (!showRepository.existsById(id)) {
            throw new ResourceNotFoundException("Show not found with ID: " + id);
        }
        showRepository.deleteById(id);
    }
}