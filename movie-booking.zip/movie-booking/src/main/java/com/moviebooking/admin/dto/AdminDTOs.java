package com.moviebooking.admin.dto;

import com.moviebooking.catalog.model.AudioLanguage;
import com.moviebooking.catalog.model.CbfcRating;
import com.moviebooking.catalog.model.MovieFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class AdminDTOs {

    // City Request
    public record CityRequest(String name, String state) {}

    // Movie Request
    public record MovieRequest(
        String title,
        String description,
        String castMembers,
        String director,
        Integer durationMinutes,
        CbfcRating cbfcRating,
        String posterUrl,
        String bannerUrl,
        LocalDate releaseDate
    ) {}

    // Theatre Request
    public record TheatreRequest(
        Long cityId,
        String name,
        String address
    ) {}

    // Assign a new THEATRE_OWNER account to a theatre in one step.
    // The owner is provisioned directly by admin (pre-verified, active) so
    // they can log in immediately with the given credentials.
    public record AssignOwnerRequest(
        String name,
        String email,
        String password
    ) {}

    // Screen Request
    public record ScreenRequest(
        String name,
        Integer totalSeats
    ) {}

    // Seat designer payload. matrix is a rows x cols grid: 1 = seat, 0 = pathway.
    public record SeatLayoutRequest(
        Integer rows,
        Integer cols,
        java.util.List<java.util.List<Integer>> matrix
    ) {}

    // Show Request
    public record ShowRequest(
        Long screenId,
        Long movieId,
        LocalDateTime startTime,
        AudioLanguage language,
        MovieFormat format,
        Boolean hasCaptions,
        BigDecimal basePrice
    ) {}
    
    public record ScreenResponse(
            Long id,
            String name,
            Integer totalSeats
        ) {}

    public record ScreenLayoutResponse(
            Long id,
            String name,
            Integer totalSeats,
            String layoutJson
        ) {}

    // Flat, cycle-free view of a Show. Built inside the service transaction so
    // the lazy movie/screen/theatre associations are initialized before Jackson
    // serializes — this is what prevents the 500 on GET /api/admin/shows.
    // Field names intentionally match what admin.js expects (movieTitle,
    // theatreName, screenName, price, format, language, hasCaptions).
    public record ShowResponse(
            Long id,
            Long movieId,
            String movieTitle,
            Long screenId,
            String screenName,
            String theatreName,
            java.time.LocalDateTime startTime,
            String language,
            String format,
            Boolean hasCaptions,
            java.math.BigDecimal price
        ) {}

        public record TheatreResponse(
            Long id,
            String name,
            String address,
            Long cityId,
            String cityName,
            List<ScreenResponse> screens,
            Long ownerId,
            String ownerName,
            String ownerEmail
        ) {}
}