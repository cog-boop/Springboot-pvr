package com.moviebooking.admin.controller;

import com.moviebooking.admin.dto.AdminDTOs.*;
import com.moviebooking.admin.service.AdminService;
import com.moviebooking.catalog.model.*;
import com.moviebooking.common.response.ApiResponse;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    // --- CITY ENDPOINTS ---
    @PostMapping("/cities")
    public ApiResponse<City> createCity(@RequestBody CityRequest req) {
        return new ApiResponse<>(true, "City created successfully", adminService.createCity(req));
    }

    @GetMapping("/cities")
    public ApiResponse<List<City>> getCities() {
        return new ApiResponse<>(true, "Cities retrieved successfully", adminService.getAllCities());
    }

    @DeleteMapping("/cities/{id}")
    public ApiResponse<Void> deleteCity(@PathVariable("id") Long id) {
        adminService.deleteCity(id);
        return new ApiResponse<>(true, "City deleted successfully", null);
    }

    // --- MOVIE ENDPOINTS ---
    @PostMapping("/movies")
    public ApiResponse<Movie> createMovie(@RequestBody MovieRequest req) {
        return new ApiResponse<>(true, "Movie added to library", adminService.createMovie(req));
    }

    @GetMapping("/movies")
    public ApiResponse<List<Movie>> getMovies() {
        return new ApiResponse<>(true, "Movies retrieved successfully", adminService.getAllMovies());
    }

    @DeleteMapping("/movies/{id}")
    public ApiResponse<Void> deleteMovie(@PathVariable("id") Long id) {
        adminService.deleteMovie(id);
        return new ApiResponse<>(true, "Movie deleted successfully", null);
    }

    // --- THEATRE & SCREEN ENDPOINTS ---
    @PostMapping("/theatres")
    public ApiResponse<TheatreResponse> createTheatre(@RequestBody TheatreRequest req) {
        return new ApiResponse<>(true, "Theatre created successfully", adminService.createTheatre(req));
    }

    @GetMapping("/theatres")
    public ApiResponse<List<TheatreResponse>> getTheatres() {
        return new ApiResponse<>(true, "Theatres retrieved successfully", adminService.getAllTheatres());
    }

    @GetMapping("/cities/{cityId}/theatres")
    public ApiResponse<List<TheatreResponse>> getTheatresByCity(@PathVariable("cityId") Long cityId) {
        return new ApiResponse<>(true, "Theatres retrieved successfully", adminService.getTheatresByCity(cityId));
    }

    @PostMapping("/theatres/{theatreId}/owner")
    public ApiResponse<TheatreResponse> assignOwner(@PathVariable("theatreId") Long theatreId, @RequestBody AssignOwnerRequest req) {
        return new ApiResponse<>(true, "Theatre owner assigned successfully", adminService.assignOwner(theatreId, req));
    }

    @DeleteMapping("/theatres/{theatreId}/owner")
    public ApiResponse<TheatreResponse> unassignOwner(@PathVariable("theatreId") Long theatreId) {
        return new ApiResponse<>(true, "Theatre owner unassigned successfully", adminService.unassignOwner(theatreId));
    }

    @PostMapping("/theatres/{theatreId}/screens")
    public ApiResponse<Screen> createScreen(@PathVariable("theatreId") Long theatreId, @RequestBody ScreenRequest req) {
        return new ApiResponse<>(true, "Screen created successfully", adminService.createScreen(theatreId, req));
    }

    @GetMapping("/theatres/{theatreId}/screens")
    public ApiResponse<List<ScreenResponse>> getScreens(@PathVariable("theatreId") Long theatreId) {
        return new ApiResponse<>(true, "Screens retrieved successfully", adminService.getScreensByTheatre(theatreId));
    }

    @PutMapping("/screens/{screenId}/layout")
    public ApiResponse<ScreenLayoutResponse> updateScreenLayout(@PathVariable("screenId") Long screenId,
                                                  @RequestBody SeatLayoutRequest req) {
        return new ApiResponse<>(true, "Seat layout updated successfully", adminService.updateScreenLayout(screenId, req));
    }

    // --- SHOW ENDPOINTS ---
    @PostMapping("/shows")
    public ApiResponse<Show> scheduleShow(@RequestBody ShowRequest req) {
        return new ApiResponse<>(true, "Show scheduled successfully", adminService.scheduleShow(req));
    }

    @GetMapping("/shows")
    public ApiResponse<List<ShowResponse>> getShows() {
        return new ApiResponse<>(true, "Shows retrieved successfully", adminService.getAllShows());
    }

    @DeleteMapping("/shows/{id}")
    public ApiResponse<Void> cancelShow(@PathVariable("id") Long id) {
        adminService.cancelShow(id);
        return new ApiResponse<>(true, "Show cancelled successfully", null);
    }
}