package com.moviebooking.owner.service;

import com.moviebooking.auth.entity.User;
import com.moviebooking.auth.repository.UserRepository;
import com.moviebooking.catalog.model.*;
import com.moviebooking.catalog.repository.*;
import com.moviebooking.common.exception.ResourceNotFoundException;
import com.moviebooking.owner.dto.OwnerDTOs.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class OwnerService {

    private final UserRepository userRepository;
    private final TheatreRepository theatreRepository;
    private final ScreenRepository screenRepository;
    private final ShowRepository showRepository;
    private final MovieRepository movieRepository;

    public OwnerService(UserRepository userRepository,
                         TheatreRepository theatreRepository,
                         ScreenRepository screenRepository,
                         ShowRepository showRepository,
                         MovieRepository movieRepository) {
        this.userRepository = userRepository;
        this.theatreRepository = theatreRepository;
        this.screenRepository = screenRepository;
        this.showRepository = showRepository;
        this.movieRepository = movieRepository;
    }

    // Resolves the theatre owned by whoever is currently authenticated.
    // This is the single choke point that guarantees an owner can never
    // reach another theatre's data - the theatreId is never taken from the client.
    private Theatre currentOwnersTheatre() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmailAndIsDeletedFalse(email)
                .orElseThrow(() -> new ResourceNotFoundException("Authenticated user not found"));

        return theatreRepository.findByOwnerId(user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No theatre is currently assigned to your account. Contact an administrator."));
    }

    public TheatreInfoResponse getMyTheatre() {
        Theatre t = currentOwnersTheatre();
        List<ScreenResponse> screens = t.getScreens() == null ? List.of() :
                t.getScreens().stream()
                        .map(s -> new ScreenResponse(s.getId(), s.getName(), s.getTotalSeats()))
                        .collect(Collectors.toList());

        return new TheatreInfoResponse(
                t.getId(), t.getName(), t.getAddress(),
                t.getCity() != null ? t.getCity().getId() : null,
                t.getCity() != null ? t.getCity().getName() : "",
                screens
        );
    }

    // --- SCREENS (scoped) ---
    public ScreenResponse createScreen(ScreenRequest req) {
        Theatre t = currentOwnersTheatre();
        Screen screen = new Screen();
        screen.setName(req.name());
        screen.setTotalSeats(req.totalSeats());
        screen.setTheatre(t);
        Screen saved = screenRepository.save(screen);
        return new ScreenResponse(saved.getId(), saved.getName(), saved.getTotalSeats());
    }

    public List<ScreenResponse> getMyScreens() {
        Theatre t = currentOwnersTheatre();
        return screenRepository.findByTheatreId(t.getId()).stream()
                .map(s -> new ScreenResponse(s.getId(), s.getName(), s.getTotalSeats()))
                .collect(Collectors.toList());
    }

    // --- MOVIE CATALOG (read-only, for the schedule-show dropdown) ---
    public List<MovieOption> getAvailableMovies() {
        return movieRepository.findAll().stream()
                .map(m -> new MovieOption(m.getId(), m.getTitle(), m.getCbfcRating(), m.getDurationMinutes()))
                .collect(Collectors.toList());
    }

    // --- SHOWS (scoped) ---
    public ShowResponse scheduleShow(ShowRequest req) {
        Theatre t = currentOwnersTheatre();

        Screen screen = screenRepository.findById(req.screenId())
                .filter(s -> s.getTheatre() != null && s.getTheatre().getId().equals(t.getId()))
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Screen not found in your theatre with ID: " + req.screenId()));

        Movie movie = movieRepository.findById(req.movieId())
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with ID: " + req.movieId()));

        Show show = new Show();
        show.setScreen(screen);
        show.setMovie(movie);
        show.setStartTime(req.startTime());
        show.setLanguage(req.language());
        show.setFormat(req.format());
        show.setHasCaptions(req.hasCaptions() != null ? req.hasCaptions() : false);
        show.setBasePrice(req.basePrice());
        Show saved = showRepository.save(show);

        return toShowResponse(saved);
    }

    public List<ShowResponse> getMyShows() {
        Theatre t = currentOwnersTheatre();
        return showRepository.findAll().stream()
                .filter(s -> s.getScreen() != null && s.getScreen().getTheatre() != null
                        && s.getScreen().getTheatre().getId().equals(t.getId()))
                .map(this::toShowResponse)
                .collect(Collectors.toList());
    }

    public void cancelShow(Long showId) {
        Theatre t = currentOwnersTheatre();
        Show show = showRepository.findById(showId)
                .filter(s -> s.getScreen() != null && s.getScreen().getTheatre() != null
                        && s.getScreen().getTheatre().getId().equals(t.getId()))
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Show not found in your theatre with ID: " + showId));
        showRepository.delete(show);
    }

    private ShowResponse toShowResponse(Show s) {
        return new ShowResponse(
                s.getId(),
                s.getMovie() != null ? s.getMovie().getId() : null,
                s.getMovie() != null ? s.getMovie().getTitle() : null,
                s.getScreen() != null ? s.getScreen().getId() : null,
                s.getScreen() != null ? s.getScreen().getName() : null,
                s.getStartTime(),
                s.getLanguage(),
                s.getFormat(),
                s.getHasCaptions(),
                s.getBasePrice()
        );
    }
}
