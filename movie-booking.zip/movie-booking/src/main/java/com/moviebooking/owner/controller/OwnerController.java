package com.moviebooking.owner.controller;

import com.moviebooking.common.response.ApiResponse;
import com.moviebooking.owner.dto.OwnerDTOs.*;
import com.moviebooking.owner.service.OwnerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/owner")
public class OwnerController {

    private final OwnerService ownerService;

    public OwnerController(OwnerService ownerService) {
        this.ownerService = ownerService;
    }

    @GetMapping("/theatre")
    public ApiResponse<TheatreInfoResponse> getMyTheatre() {
        return new ApiResponse<>(true, "Theatre details retrieved successfully", ownerService.getMyTheatre());
    }

    @PostMapping("/screens")
    public ApiResponse<ScreenResponse> createScreen(@RequestBody ScreenRequest req) {
        return new ApiResponse<>(true, "Screen created successfully", ownerService.createScreen(req));
    }

    @GetMapping("/screens")
    public ApiResponse<List<ScreenResponse>> getMyScreens() {
        return new ApiResponse<>(true, "Screens retrieved successfully", ownerService.getMyScreens());
    }

    @GetMapping("/movies")
    public ApiResponse<List<MovieOption>> getAvailableMovies() {
        return new ApiResponse<>(true, "Movies retrieved successfully", ownerService.getAvailableMovies());
    }

    @PostMapping("/shows")
    public ApiResponse<ShowResponse> scheduleShow(@RequestBody ShowRequest req) {
        return new ApiResponse<>(true, "Show scheduled successfully", ownerService.scheduleShow(req));
    }

    @GetMapping("/shows")
    public ApiResponse<List<ShowResponse>> getMyShows() {
        return new ApiResponse<>(true, "Shows retrieved successfully", ownerService.getMyShows());
    }

    @DeleteMapping("/shows/{id}")
    public ApiResponse<Void> cancelShow(@PathVariable("id") Long id) {
        ownerService.cancelShow(id);
        return new ApiResponse<>(true, "Show cancelled successfully", null);
    }
}
