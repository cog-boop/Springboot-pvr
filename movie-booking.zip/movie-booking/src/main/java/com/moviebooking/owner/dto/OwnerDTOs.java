package com.moviebooking.owner.dto;

import com.moviebooking.catalog.model.AudioLanguage;
import com.moviebooking.catalog.model.CbfcRating;
import com.moviebooking.catalog.model.MovieFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class OwnerDTOs {

    // Screen Request - theatre is always inferred from the authenticated owner's token
    public record ScreenRequest(
        String name,
        Integer totalSeats
    ) {}

    public record ScreenResponse(
        Long id,
        String name,
        Integer totalSeats
    ) {}

    // Show Request - screenId must belong to the owner's own theatre (validated server-side)
    public record ShowRequest(
        Long screenId,
        Long movieId,
        LocalDateTime startTime,
        AudioLanguage language,
        MovieFormat format,
        Boolean hasCaptions,
        BigDecimal basePrice
    ) {}

    public record ShowResponse(
        Long id,
        Long movieId,
        String movieTitle,
        Long screenId,
        String screenName,
        LocalDateTime startTime,
        AudioLanguage language,
        MovieFormat format,
        Boolean hasCaptions,
        BigDecimal basePrice
    ) {}

    public record MovieOption(
        Long id,
        String title,
        CbfcRating cbfcRating,
        Integer durationMinutes
    ) {}

    public record TheatreInfoResponse(
        Long id,
        String name,
        String address,
        Long cityId,
        String cityName,
        List<ScreenResponse> screens
    ) {}
}
