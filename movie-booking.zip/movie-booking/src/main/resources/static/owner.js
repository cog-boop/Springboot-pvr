const API_BASE = '/api/owner';

document.addEventListener('DOMContentLoaded', () => {
    if (checkOwnerAuth()) {
        loadMyTheatre();
        loadMyScreens();
        loadMovieOptions();
        loadMyShows();
    }
});

function checkOwnerAuth() {
    const token = localStorage.getItem('accessToken');
    if (!token) {
        window.location.href = '/auth.html';
        return false;
    }

    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const role = payload.role || payload.roles || '';

        if (!role.includes('THEATRE_OWNER') && !role.includes('ADMIN')) {
            alert('Access Denied. Theatre owner privileges required.');
            handleLogout();
            return false;
        }

        const emailDisplay = document.getElementById('ownerEmailDisplay');
        if (emailDisplay && payload.sub) {
            emailDisplay.innerText = payload.sub;
        }
        return true;
    } catch (e) {
        console.error('Invalid token format:', e);
        handleLogout();
        return false;
    }
}

async function ownerApiCall(endpoint, method = 'GET', body = null) {
    hideAlert();
    const token = localStorage.getItem('accessToken');
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };

    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null
        });

        if (response.status === 401 || response.status === 403) {
            showAlert('Session expired or unauthorized. Please log in again.', 'error');
            setTimeout(handleLogout, 1500);
            return null;
        }

        const result = await response.json();

        if (!response.ok || (result.success !== undefined && !result.success)) {
            const errorMsg = result.message || result.error || `HTTP ${response.status} Error`;
            showAlert(errorMsg, 'error');
            throw new Error(errorMsg);
        }

        return result;
    } catch (err) {
        if (err.message && err.message !== 'Failed to fetch') throw err;
        showAlert('Network error. Please check your connection.', 'error');
        throw err;
    }
}

function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));

    const target = document.getElementById(tabId);
    if (target) target.classList.remove('hidden');
    if (event && event.currentTarget) event.currentTarget.classList.add('active');
}

function showAlert(message, type = 'error') {
    const alertBox = document.getElementById('ownerAlert');
    if (!alertBox) return;
    alertBox.className = `alert alert-${type}`;
    alertBox.textContent = message;
    alertBox.classList.remove('hidden');
}

function hideAlert() {
    const alertBox = document.getElementById('ownerAlert');
    if (alertBox) alertBox.classList.add('hidden');
}

function handleLogout() {
    localStorage.clear();
    window.location.href = '/auth.html';
}

// --- MY THEATRE ---
async function loadMyTheatre() {
    try {
        const res = await ownerApiCall('/theatre');
        if (!res) return;
        const t = res.data;
        const card = document.getElementById('theatreInfoCard');
        card.innerHTML = `
            <h3 style="color: var(--primary-gold);">${t.name}</h3>
            <p style="color: var(--text-muted); margin-top: 4px;">${t.address}, ${t.cityName}</p>
            <p style="margin-top: 8px; font-size: 0.85rem; color: var(--text-muted);">
                ${t.screens ? t.screens.length : 0} screen(s) configured.
            </p>
        `;
    } catch (_) {
        const card = document.getElementById('theatreInfoCard');
        if (card) card.innerHTML = `<p style="color: var(--text-muted);">No theatre is currently assigned to your account. Contact an administrator.</p>`;
    }
}

// --- SCREENS ---
async function loadMyScreens() {
    try {
        const res = await ownerApiCall('/screens');
        if (!res) return;
        const tbody = document.getElementById('screensTableBody');
        const screenSelect = document.getElementById('showScreenSelect');
        tbody.innerHTML = '';
        if (screenSelect) screenSelect.innerHTML = '<option value="" disabled selected>Select Screen</option>';

        res.data.forEach(s => {
            tbody.innerHTML += `
                <tr>
                    <td>${s.id}</td>
                    <td>${s.name}</td>
                    <td>${s.totalSeats}</td>
                </tr>
            `;
            if (screenSelect) {
                screenSelect.innerHTML += `<option value="${s.id}">${s.name} (${s.totalSeats} seats)</option>`;
            }
        });
    } catch (_) {}
}

document.getElementById('addScreenForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('screenName').value.trim();
    const totalSeats = parseInt(document.getElementById('screenTotalSeats').value, 10);

    try {
        await ownerApiCall('/screens', 'POST', { name, totalSeats });
        showAlert('Screen added successfully!', 'success');
        document.getElementById('addScreenForm').reset();
        loadMyScreens();
        loadMyTheatre();
    } catch (_) {}
});

// --- MOVIES (read-only dropdown source) ---
async function loadMovieOptions() {
    try {
        const res = await ownerApiCall('/movies');
        if (!res) return;
        const movieSelect = document.getElementById('showMovieSelect');
        if (!movieSelect) return;
        movieSelect.innerHTML = '<option value="" disabled selected>Select Movie</option>';
        res.data.forEach(m => {
            movieSelect.innerHTML += `<option value="${m.id}">${m.title} (${m.cbfcRating})</option>`;
        });
    } catch (_) {}
}

// --- SHOWS ---
async function loadMyShows() {
    try {
        const res = await ownerApiCall('/shows');
        if (!res) return;
        const tbody = document.getElementById('showsTableBody');
        tbody.innerHTML = '';
        res.data.forEach(s => {
            const start = s.startTime ? new Date(s.startTime).toLocaleString() : '';
            tbody.innerHTML += `
                <tr>
                    <td>${s.movieTitle || ''}</td>
                    <td>${s.screenName || ''}</td>
                    <td>${start}</td>
                    <td>${s.format || ''}</td>
                    <td>₹${s.basePrice}</td>
                    <td><button class="btn-danger-sm" onclick="cancelShow(${s.id})">Cancel</button></td>
                </tr>
            `;
        });
    } catch (_) {}
}

document.getElementById('addShowForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const screenId = parseInt(document.getElementById('showScreenSelect').value, 10);
    const movieId = parseInt(document.getElementById('showMovieSelect').value, 10);
    const language = document.getElementById('showLanguage').value;
    const format = document.getElementById('showFormat').value;
    const startTime = document.getElementById('showStartTime').value;
    const basePrice = parseFloat(document.getElementById('showPrice').value);
    const hasCaptions = document.getElementById('showCaptions').checked;

    if (!screenId || !movieId) {
        showAlert('Please select both a screen and a movie.', 'error');
        return;
    }

    try {
        await ownerApiCall('/shows', 'POST', {
            screenId, movieId, language, format, startTime, basePrice, hasCaptions
        });
        showAlert('Show scheduled successfully!', 'success');
        document.getElementById('addShowForm').reset();
        loadMyShows();
    } catch (_) {}
});

async function cancelShow(id) {
    if (!confirm('Cancel this show?')) return;
    try {
        await ownerApiCall(`/shows/${id}`, 'DELETE');
        showAlert('Show cancelled.', 'success');
        loadMyShows();
    } catch (_) {}
}
