const API_BASE = '/catalog';

// State
let selectedCityId = localStorage.getItem('selectedCityId') || null;
let currentMovieId = null;
let selectedDate = new Date().toISOString().split('T')[0];
let pendingShowBooking = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadCities();
    checkAuthState();
});

// Auth Check (matching auth.js token key "accessToken")
function isAuthenticated() {
    return !!localStorage.getItem('accessToken');
}

function checkAuthState() {
    const authNav = document.getElementById('authNav');
    if (isAuthenticated()) {
        authNav.innerHTML = `<button class="btn btn-secondary btn-sm" onclick="window.location.href='/auth.html'">My Account</button>`;
    } else {
        authNav.innerHTML = `<button class="btn btn-primary btn-sm" onclick="redirectToLogin()">Sign In</button>`;
    }
}

// 1. Load Cities
async function loadCities() {
    try {
        const res = await fetch(`${API_BASE}/cities`);
        const result = await res.json();

        if (result.success) {
            const citySelect = document.getElementById('citySelect');
            citySelect.innerHTML = '<option value="" disabled>Select City</option>';

            result.data.forEach(city => {
                const opt = document.createElement('option');
                opt.value = city.id;
                opt.textContent = `${city.name}, ${city.state}`;
                if (String(city.id) === String(selectedCityId)) {
                    opt.selected = true;
                }
                citySelect.appendChild(opt);
            });

            if (!selectedCityId && result.data.length > 0) {
                selectedCityId = result.data[0].id;
                citySelect.value = selectedCityId;
                localStorage.setItem('selectedCityId', selectedCityId);
            }

            if (selectedCityId) {
                const activeCity = result.data.find(c => String(c.id) === String(selectedCityId));
                if (activeCity) {
                    document.getElementById('activeCityLabel').textContent = activeCity.name;
                }
                loadMoviesForCity(selectedCityId);
            }
        }
    } catch (err) {
        console.error('Failed to load cities:', err);
    }
}

function handleCityChange(cityId) {
    selectedCityId = cityId;
    localStorage.setItem('selectedCityId', cityId);
    
    const citySelect = document.getElementById('citySelect');
    document.getElementById('activeCityLabel').textContent = citySelect.options[citySelect.selectedIndex].text.split(',')[0];
    
    navigateToHome();
    loadMoviesForCity(cityId);
}

// 2. Load Movies
async function loadMoviesForCity(cityId) {
    try {
        const res = await fetch(`${API_BASE}/movies?cityId=${cityId}`);
        const result = await res.json();

        const grid = document.getElementById('movieGrid');
        grid.innerHTML = '';

        if (!result.data || result.data.length === 0) {
            grid.innerHTML = `<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted);">No movies currently running in this city.</p>`;
            return;
        }

        result.data.forEach(movie => {
            const card = document.createElement('div');
            card.className = 'movie-card';
            card.onclick = () => loadMovieDetails(movie.id);

            card.innerHTML = `
                <img src="${movie.posterUrl || 'https://via.placeholder.com/300x400?text=No+Poster'}" alt="${movie.title}">
                <div class="movie-card-body">
                    <div class="movie-card-title">${movie.title}</div>
                    <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 8px;">
                        <span class="badge badge-gold">${movie.cbfcRating}</span>
                        <span style="font-size: 0.8rem; color: var(--text-muted);">${movie.durationMinutes}m</span>
                    </div>
                    <div class="tag-group">
                        ${movie.availableFormats.map(f => `<span class="badge badge-pill">${f}</span>`).join('')}
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
    } catch (err) {
        console.error('Error fetching movies:', err);
    }
}

// 3. Movie Details & Showtimes View
async function loadMovieDetails(movieId) {
    currentMovieId = movieId;
    try {
        const res = await fetch(`${API_BASE}/movies/${movieId}?cityId=${selectedCityId}`);
        const result = await res.json();

        if (!result.success) return;

        const movie = result.data;

        // Populate Details
        document.getElementById('detailTitle').textContent = movie.title;
        document.getElementById('detailCbfc').textContent = movie.cbfcRating;
        document.getElementById('detailRuntime').textContent = `${movie.durationMinutes} min`;
        document.getElementById('detailRelease').textContent = movie.releaseDate;
        document.getElementById('detailDescription').textContent = movie.description;
        document.getElementById('detailCast').textContent = movie.castMembers;
        document.getElementById('detailPoster').src = movie.posterUrl || 'https://via.placeholder.com/200x300';

        if (movie.bannerUrl) {
            document.getElementById('movieBanner').style.backgroundImage = `url('${movie.bannerUrl}')`;
        }

        // Tags
        document.getElementById('detailLanguages').innerHTML = movie.availableLanguages
            .map(l => `<span class="badge badge-pill">${l}</span>`).join('');
        
        document.getElementById('detailFormats').innerHTML = movie.availableFormats
            .map(f => `<span class="badge badge-pill">${f}</span>`).join('');

        if (movie.hasCaptions) {
            document.getElementById('detailCaptions').classList.remove('hidden');
        } else {
            document.getElementById('detailCaptions').classList.add('hidden');
        }

        // Switch Views
        document.getElementById('movieGridView').classList.add('hidden');
        document.getElementById('movieDetailView').classList.remove('hidden');

        // Render Date Bar & Load Shows
        renderDateBar();
        loadShowtimes();

    } catch (err) {
        console.error('Error loading movie details:', err);
    }
}

// Date Selector Bar
function renderDateBar() {
    const dateBar = document.getElementById('dateBar');
    dateBar.innerHTML = '';

    const today = new Date();

    for (let i = 0; i < 7; i++) {
        const d = new Date(today);
        d.setDate(today.getDate() + i);

        const isoDate = d.toISOString().split('T')[0];
        const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
        const dateNum = d.getDate();
        const monthName = d.toLocaleDateString('en-US', { month: 'short' });

        const chip = document.createElement('div');
        chip.className = `date-chip ${isoDate === selectedDate ? 'active' : ''}`;
        chip.onclick = () => {
            selectedDate = isoDate;
            document.querySelectorAll('.date-chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            loadShowtimes();
        };

        chip.innerHTML = `
            <span class="day">${dayName}</span>
            <span class="date-num">${dateNum} ${monthName}</span>
        `;

        dateBar.appendChild(chip);
    }
}

// Fetch and Render Shows
async function loadShowtimes() {
    const list = document.getElementById('theatreList');
    list.innerHTML = '<p style="color: var(--text-muted);">Loading showtimes...</p>';

    try {
        const res = await fetch(`${API_BASE}/movies/${currentMovieId}/shows?cityId=${selectedCityId}&date=${selectedDate}`);
        const result = await res.json();

        list.innerHTML = '';

        if (!result.data || result.data.length === 0) {
            list.innerHTML = `<p style="color: var(--text-muted); padding: 16px 0;">No shows available for the selected date.</p>`;
            return;
        }

        result.data.forEach(theatre => {
            const card = document.createElement('div');
            card.className = 'theatre-card';

            const showChipsHtml = theatre.shows.map(show => {
                const showTime = new Date(show.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const safeTheatreName = theatre.theatreName.replace(/'/g, "\\'");
                const safeScreenName = show.screenName.replace(/'/g, "\\'");
                return `
                    <div class="show-chip" onclick="handleShowSelection(${show.showId}, '${safeTheatreName}', '${showTime}', '${safeScreenName}')">
                        <div class="time">${showTime}</div>
                        <div class="sub-info">${show.format} • ₹${show.price}</div>
                    </div>
                `;
            }).join('');

            card.innerHTML = `
                <div class="theatre-name">${theatre.theatreName}</div>
                <div class="theatre-address">${theatre.address}</div>
                <div class="showtime-chips">${showChipsHtml}</div>
            `;

            list.appendChild(card);
        });

    } catch (err) {
        console.error('Error fetching showtimes:', err);
    }
}

// 4. Booking Auth Gate
function handleShowSelection(showId, theatreName, time, screenName) {
    if (!isAuthenticated()) {
        pendingShowBooking = { showId, theatreName, time, screenName };
        openAuthModal();
    } else {
        initiateBooking(showId, theatreName, time, screenName);
    }
}

// Navigation & Modal Helpers
function navigateToHome() {
    document.getElementById('movieDetailView').classList.add('hidden');
    document.getElementById('movieGridView').classList.remove('hidden');
}

function scrollToShowtimes() {
    document.getElementById('showtimesSection').scrollIntoView({ behavior: 'smooth' });
}

function openAuthModal() {
    document.getElementById('authModal').classList.remove('hidden');
}

function closeAuthModal() {
    document.getElementById('authModal').classList.add('hidden');
    pendingShowBooking = null;
}

function redirectToLogin() {
    window.location.href = '/auth.html';
}

// =========================================
// VIEW 4: SEAT SELECTION & CHECKOUT LOGIC
// =========================================

const BOOKING_API_BASE = '/api/booking';
const MAX_SEATS = 10;

let activeShowContext = null;
let selectedSeats = [];
let pricePerSeat = 0;
let activeBookingId = null;
let holdCountdownInterval = null;

// Authenticated helper - booking endpoints always require a valid JWT
async function bookingApiCall(endpoint, method = 'GET', body = null) {
    const token = localStorage.getItem('accessToken');
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };

    const response = await fetch(`${BOOKING_API_BASE}${endpoint}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : null
    });

    const result = await response.json();

    if (response.status === 401 || response.status === 403) {
        showAlert('Session expired. Please sign in again.', 'error');
        setTimeout(() => window.location.href = '/auth.html', 1500);
        throw new Error('Unauthorized');
    }

    if (!response.ok || result.success === false) {
        showAlert(result.message || 'Something went wrong.', 'error');
        throw new Error(result.message || 'Request failed');
    }

    return result;
}

// 1. Triggered when a user clicks a showtime pill in VIEW 3
async function initiateBooking(showId, theatreName, time, screenName) {
    if (!isAuthenticated()) {
        openAuthModal();
        return;
    }

    activeShowContext = { showId, theatreName, time, screenName };
    selectedSeats = [];
    activeBookingId = null;
    clearHoldCountdown();
    updateCheckoutBar();

    document.getElementById('bookingMovieTitle').innerText = document.getElementById('detailTitle').innerText;
    document.getElementById('bookingTheatreName').innerText = `${theatreName} - ${screenName}`;
    document.getElementById('bookingShowtime').innerText = time;

    document.getElementById('movieDetailView').classList.add('hidden');
    document.getElementById('seatSelectionView').classList.remove('hidden');

    await fetchAndRenderSeats(showId);
}

// 2. Fetch real seat inventory for this show and render the grid
async function fetchAndRenderSeats(showId) {
    const grid = document.getElementById('seatGrid');
    grid.innerHTML = '<div class="loading-spinner">Loading seats...</div>';

    try {
        const res = await bookingApiCall(`/shows/${showId}/seats`, 'GET');
        const { rows, seatsPerRow, seats, pricePerSeat: price } = res.data;
        pricePerSeat = price;

        grid.innerHTML = '';
        grid.style.gridTemplateColumns = `repeat(${seatsPerRow}, 32px)`;

        seats.forEach(seat => {
            const seatDiv = document.createElement('div');
            const statusClass = seat.status === 'BOOKED' ? 'booked'
                : (seat.status === 'HELD' && !seat.heldByMe) ? 'booked'
                : 'available';

            seatDiv.className = `seat ${statusClass}`;
            seatDiv.innerText = seat.seatCode;
            seatDiv.dataset.id = seat.seatCode;

            if (statusClass === 'available') {
                seatDiv.onclick = () => toggleSeatSelection(seatDiv, seat.seatCode);
            }
            grid.appendChild(seatDiv);
        });
    } catch (err) {
        grid.innerHTML = '<p class="error-text">Failed to load seat layout.</p>';
    }
}

// 3. Handle Tap on Seat
function toggleSeatSelection(seatDiv, seatId) {
    if (seatDiv.classList.contains('selected')) {
        seatDiv.classList.remove('selected');
        seatDiv.classList.add('available');
        selectedSeats = selectedSeats.filter(id => id !== seatId);
    } else {
        if (selectedSeats.length >= MAX_SEATS) {
            showAlert(`Maximum ${MAX_SEATS} tickets allowed per transaction.`, 'error');
            return;
        }
        seatDiv.classList.remove('available');
        seatDiv.classList.add('selected');
        selectedSeats.push(seatId);
    }
    updateCheckoutBar();
}

// 4. Update Bottom Sticky Bar
function updateCheckoutBar() {
    const checkoutBar = document.getElementById('checkoutBar');
    const countDisplay = document.getElementById('selectedSeatCount');
    const priceDisplay = document.getElementById('totalPriceDisplay');

    if (selectedSeats.length > 0) {
        checkoutBar.classList.remove('hidden');
        countDisplay.innerText = `${selectedSeats.length} Ticket${selectedSeats.length > 1 ? 's' : ''}`;
        priceDisplay.innerText = `₹ ${selectedSeats.length * pricePerSeat}`;
    } else {
        checkoutBar.classList.add('hidden');
    }
}

// Navigation helpers
function goBackToMovieDetail() {
    document.getElementById('seatSelectionView').classList.add('hidden');
    document.getElementById('movieDetailView').classList.remove('hidden');
    selectedSeats = [];
    clearHoldCountdown();
    updateCheckoutBar();
}

// 5. Hold the selected seats for 10 minutes (non-refundable policy shown before payment)
async function proceedToPayment() {
    if (selectedSeats.length === 0) return;

    const confirmed = confirm(
        `You're about to hold ${selectedSeats.length} seat(s) for 10 minutes.\n\n` +
        `Tickets are 100% NON-REFUNDABLE once payment is completed.\n\nContinue?`
    );
    if (!confirmed) return;

    try {
        const res = await bookingApiCall('/hold', 'POST', {
            showId: activeShowContext.showId,
            seatCodes: selectedSeats
        });

        const booking = res.data;
        activeBookingId = booking.bookingId;

        showAlert(
            `Seats held: ${booking.seatCodes.join(', ')} | Total ₹${booking.totalAmount} | ` +
            `Transaction ref: ${booking.transactionId}. Complete payment within 10 minutes.`,
            'success'
        );

        startHoldCountdown(booking.holdExpiresAt);
        // Payment module (Razorpay) plugs in here next - for now the hold itself
        // is the end of the booking-core flow.
    } catch (err) {
        // Error already shown by bookingApiCall; refresh seat map since
        // someone may have grabbed a seat in the meantime.
        await fetchAndRenderSeats(activeShowContext.showId);
        selectedSeats = [];
        updateCheckoutBar();
    }
}

function startHoldCountdown(expiresAtIso) {
    clearHoldCountdown();
    const expiresAt = new Date(expiresAtIso).getTime();

    holdCountdownInterval = setInterval(() => {
        const remainingMs = expiresAt - Date.now();
        if (remainingMs <= 0) {
            clearHoldCountdown();
            showAlert('Your seat hold has expired. Please select seats again.', 'error');
            selectedSeats = [];
            activeBookingId = null;
            updateCheckoutBar();
            fetchAndRenderSeats(activeShowContext.showId);
            return;
        }
        const mins = Math.floor(remainingMs / 60000);
        const secs = Math.floor((remainingMs % 60000) / 1000);
        document.getElementById('totalPriceDisplay').innerText =
            `₹ ${selectedSeats.length * pricePerSeat} (Hold: ${mins}:${secs.toString().padStart(2, '0')})`;
    }, 1000);
}

function clearHoldCountdown() {
    if (holdCountdownInterval) {
        clearInterval(holdCountdownInterval);
        holdCountdownInterval = null;
    }
}