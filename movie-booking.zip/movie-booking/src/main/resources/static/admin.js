const API_BASE = '/api/admin';

// Initialize and verify authentication on boot
document.addEventListener('DOMContentLoaded', () => {
    if (checkAdminAuth()) {
        loadCities();
        loadMovies();
        loadTheatres();
        loadShows();
    }
});

function checkAdminAuth() {
    const token = localStorage.getItem('accessToken');
    if (!token) {
        window.location.href = '/auth.html';
        return false;
    }

    try {
        // Decode JWT payload to check role and display email
        const payload = JSON.parse(atob(token.split('.')[1]));
        const role = payload.role || payload.roles || '';
        
        // Ensure user holds ADMIN role
        if (!role.includes('ADMIN')) {
            alert('Access Denied. Admin privileges required.');
            handleLogout();
            return false;
        }

        // Display logged-in admin email in navbar if present
        const emailDisplay = document.getElementById('adminEmailDisplay');
        if (emailDisplay && payload.sub) {
            emailDisplay.innerText = payload.sub;
        }
        return true;
    } catch (e) {
        console.error('Invalid token format:', e);
        handleLogout();
        return false;
    }
}

// Global API Helper with JWT Authorization header
async function adminApiCall(endpoint, method = 'GET', body = null) {
    hideAlert();
    const token = localStorage.getItem('accessToken');
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };
	
	//add it localhost in apibase and see if it works

    try {
        console.log(`[API REQUEST] ${method} ${API_BASE}${endpoint}`, body);

        const response = await fetch(`${API_BASE}${endpoint}`, {
            method,
            headers,
            cache: 'no-store', // never serve a stale cached GET; always hit the server
            body: body ? JSON.stringify(body) : null
        });

        console.log(`[API RESPONSE STATUS] ${response.status} ${response.statusText}`);

        if (response.status === 401 || response.status === 403) {
            showAlert('Session expired or unauthorized. Please log in again.', 'error');
            setTimeout(handleLogout, 1500);
            return null;
        }

        const result = await response.json();
        console.log(`[API RESPONSE BODY]`, result);

        if (!response.ok || (result.success !== undefined && !result.success)) {
            const errorMsg = result.message || result.error || `HTTP ${response.status} Error`;
            showAlert(errorMsg, 'error');
            throw new Error(errorMsg);
        }

        return result;
    } catch (err) {
        console.error(`[API ERROR] Endpoint: ${endpoint}`, err);
        throw err;
    }
}

// Prevents duplicate submissions from rapid/double clicks (or Enter spam).
// Disables the form's submit button for the duration of the async task, so a
// second click cannot fire a second POST before the first one resolves.
async function withSubmitGuard(formEl, task) {
    const btn = formEl ? formEl.querySelector('button[type="submit"], button:not([type])') : null;
    if (btn) {
        if (btn.dataset.busy === '1') return; // already running — ignore this click
        btn.dataset.busy = '1';
        btn.disabled = true;
    }
    try {
        await task();
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.dataset.busy = '0';
        }
    }
}

// Navigation Tab Switcher
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));

    const target = document.getElementById(tabId);
    if (target) {
        target.classList.remove('hidden');
    }
    if (event && event.currentTarget) {
        event.currentTarget.classList.add('active');
    }
}

// Alert Banners
function showAlert(message, type = 'error') {
    const alertBox = document.getElementById('adminAlert');
    if (!alertBox) return;
    alertBox.className = `alert alert-${type}`;
    alertBox.textContent = message;
    alertBox.classList.remove('hidden');
}

function hideAlert() {
    const alertBox = document.getElementById('adminAlert');
    if (alertBox) alertBox.classList.add('hidden');
}

// Logout
function handleLogout() {
    localStorage.clear();
    window.location.href = '/auth.html';
}

// --- 1. CITY MANAGEMENT ---
async function loadCities() {
    try {
        const res = await adminApiCall('/cities');
        if (!res) return;
        const tbody = document.getElementById('citiesTableBody');
        tbody.innerHTML = '';

        // Populate dropdowns across other forms as well
        const cityDropdowns = [
            document.getElementById('theatreCitySelect'),
            document.getElementById('showCitySelect')
        ];
        cityDropdowns.forEach(d => {
            if (d) d.innerHTML = '<option value="" disabled selected>Select City</option>';
        });

        res.data.forEach(city => {
            // Table row
            tbody.innerHTML += `
                <tr>
                    <td>${city.id}</td>
                    <td><strong>${city.name}</strong></td>
                    <td>${city.state}</td>
                    <td>
                        <button class="btn-danger-sm" onclick="deleteCity(${city.id})">Delete</button>
                    </td>
                </tr>
            `;

            // Dropdown options
            cityDropdowns.forEach(d => {
                if (d) d.innerHTML += `<option value="${city.id}">${city.name}, ${city.state}</option>`;
            });
        });
    } catch (_) {}
}

document.getElementById('addCityForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('cityName').value.trim();
    const state = document.getElementById('cityState').value.trim();

    try {
        await adminApiCall('/cities', 'POST', { name, state });
        showAlert('City added successfully!', 'success');
        document.getElementById('addCityForm').reset();
        loadCities();
    } catch (_) {}
});

async function deleteCity(id) {
    if (!confirm('Are you sure you want to delete this city?')) return;
    try {
        await adminApiCall(`/cities/${id}`, 'DELETE');
        showAlert('City deleted.', 'success');
        loadCities();
    } catch (_) {}
}

// --- 2. MOVIE LIBRARY MANAGEMENT ---
async function loadMovies() {
    try {
        const res = await adminApiCall('/movies');
        if (!res) return;
        const tbody = document.getElementById('moviesTableBody');
        const movieSelect = document.getElementById('showMovieSelect');
        
        tbody.innerHTML = '';
        if (movieSelect) movieSelect.innerHTML = '<option value="" disabled selected>Select Movie</option>';

        res.data.forEach(movie => {
            tbody.innerHTML += `
                <tr>
                    <td><img src="${movie.posterUrl}" alt="poster" style="width: 40px; height: 60px; object-fit: cover; border-radius: 4px;"></td>
                    <td><strong>${movie.title}</strong></td>
                    <td>${movie.cbfcRating}</td>
                    <td>${movie.durationMinutes}m</td>
                    <td>${movie.availableLanguages.join(', ')}</td>
                    <td>
                        <button class="btn-danger-sm" onclick="deleteMovie(${movie.id})">Delete</button>
                    </td>
                </tr>
            `;

            if (movieSelect) {
                movieSelect.innerHTML += `<option value="${movie.id}">${movie.title} (${movie.cbfcRating})</option>`;
            }
        });
    } catch (_) {}
}

document.getElementById('addMovieForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
        title: document.getElementById('movieTitle').value,
        cbfcRating: document.getElementById('movieCbfc').value,
        durationMinutes: parseInt(document.getElementById('movieDuration').value),
        releaseDate: document.getElementById('movieRelease').value,
        availableLanguages: document.getElementById('movieLanguages').value.split(',').map(s => s.trim()),
        availableFormats: document.getElementById('movieFormats').value.split(',').map(s => s.trim()),
        posterUrl: document.getElementById('moviePoster').value,
        bannerUrl: document.getElementById('movieBanner').value,
        castMembers: document.getElementById('movieCast').value,
        description: document.getElementById('movieDesc').value
    };

    try {
        await adminApiCall('/movies', 'POST', payload);
        showAlert('Movie added to master library!', 'success');
        document.getElementById('addMovieForm').reset();
        loadMovies();
    } catch (_) {}
});

async function deleteMovie(id) {
    if (!confirm('Delete this movie record?')) return;
    try {
        await adminApiCall(`/movies/${id}`, 'DELETE');
        showAlert('Movie deleted.', 'success');
        loadMovies();
    } catch (_) {}
}

// --- 3. THEATRES & SCREENS MANAGEMENT ---
async function loadTheatres() {
    try {
        const res = await adminApiCall('/theatres');
        if (!res) return;
        const container = document.getElementById('theatresListContainer');
        const screenTheatreSelect = document.getElementById('screenTheatreSelect');

        container.innerHTML = '';
        if (screenTheatreSelect) screenTheatreSelect.innerHTML = '<option value="" disabled selected>Select Theatre</option>';

        res.data.forEach(t => {
            if (screenTheatreSelect) {
                screenTheatreSelect.innerHTML += `<option value="${t.id}">${t.name} (${t.cityName})</option>`;
            }

			const screenListHtml = t.screens && t.screens.length > 0 
			    ? t.screens.map(s => `
			        <li style="margin-top: 8px; color: var(--text-muted); display: flex; justify-content: space-between; align-items: center;">
			            <span>${s.name} - ${s.totalSeats} Seats</span>
			            <button class="btn-secondary-sm" onclick="openSeatModal(${s.id})">⚙️ Design Layout</button>
			        </li>
			      `).join('')
			    : '<li style="color: var(--text-muted); font-style: italic;">No screens configured yet.</li>';

			const ownerHtml = t.ownerId
			    ? `<span style="color: var(--text-muted);">👤 Owner: <strong style="color:#ccc;">${t.ownerName}</strong> (${t.ownerEmail})</span>
			       <button class="btn-danger-sm" onclick="unassignOwner(${t.id})">Unassign</button>`
			    : `<span style="color: var(--text-muted); font-style: italic;">No owner assigned</span>
			       <button class="btn-secondary-sm" onclick="assignOwner(${t.id})">Assign Owner</button>`;

            container.innerHTML += `
                <div style="background-color: #0b0c0e; border: 1px solid var(--border-color); padding: 12px; border-radius: 4px; margin-bottom: 12px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <strong style="color: var(--primary-gold);">${t.name}</strong>
                        <span style="font-size: 0.75rem; color: var(--text-muted);">${t.cityName}</span>
                    </div>
                    <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;">${t.address}</div>
                    <div style="font-size: 0.8rem; margin-top: 8px; display: flex; justify-content: space-between; align-items: center;">
                        ${ownerHtml}
                    </div>
                    <ul style="margin-top: 8px; padding-left: 16px; font-size: 0.85rem;">
                        ${screenListHtml}
                    </ul>
                </div>
            `;
        });
    } catch (_) {}
}

async function assignOwner(theatreId) {
    const name = prompt('Theatre owner full name:');
    if (!name) return;
    const email = prompt('Theatre owner email (they will log in with this):');
    if (!email) return;
    const password = prompt('Set a temporary password for this owner (min 8 chars, upper+lower+number+special):');
    if (!password) return;

    try {
        await adminApiCall(`/theatres/${theatreId}/owner`, 'POST', { name, email, password });
        showAlert('Owner assigned. Share these login credentials with them.', 'success');
        loadTheatres();
    } catch (_) {}
}

async function unassignOwner(theatreId) {
    if (!confirm('Unassign the current owner from this theatre?')) return;
    try {
        await adminApiCall(`/theatres/${theatreId}/owner`, 'DELETE');
        showAlert('Owner unassigned.', 'success');
        loadTheatres();
    } catch (_) {}
}

document.getElementById('addTheatreForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const cityIdRaw = document.getElementById('theatreCitySelect').value;
    const name = document.getElementById('theatreName').value.trim();
    const address = document.getElementById('theatreAddress').value.trim();

    if (!cityIdRaw) {
        showAlert('Please select a city.', 'error');
        return;
    }

    const cityId = parseInt(cityIdRaw, 10); // Convert string "1" to integer 1

    try {
        await adminApiCall('/theatres', 'POST', { cityId, name, address });
        showAlert('Theatre registered successfully!', 'success');
        document.getElementById('addTheatreForm').reset();
        loadTheatres();
    } catch (err) {
        // Fallback: If your Spring Boot backend uses Entity mapping @ManyToOne City city
        console.warn('Retrying with nested city object structure...');
        try {
            await adminApiCall('/theatres', 'POST', { 
                city: { id: cityId }, 
                name, 
                address 
            });
            showAlert('Theatre registered successfully!', 'success');
            document.getElementById('addTheatreForm').reset();
            loadTheatres();
        } catch (_) {}
    }
});
document.getElementById('addScreenForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    await withSubmitGuard(e.currentTarget, async () => {
        const theatreId = document.getElementById('screenTheatreSelect').value;
        const name = document.getElementById('screenName').value;
        const totalSeats = parseInt(document.getElementById('screenTotalSeats').value);

        try {
            await adminApiCall(`/theatres/${theatreId}/screens`, 'POST', { name, totalSeats });
            showAlert('Screen added to theatre!', 'success');
            document.getElementById('addScreenForm').reset();
            loadTheatres();
        } catch (_) {}
    });
});

// Cascading Selectors for Shows Scheduler
async function loadTheatresForCity(cityId) {
    const theatreSelect = document.getElementById('showTheatreSelect');
    theatreSelect.innerHTML = '<option value="" disabled selected>Loading...</option>';
    try {
        const res = await adminApiCall(`/cities/${cityId}/theatres`);
        if (!res) return;
        theatreSelect.innerHTML = '<option value="" disabled selected>Select Theatre</option>';
        res.data.forEach(t => {
            theatreSelect.innerHTML += `<option value="${t.id}">${t.name}</option>`;
        });
    } catch (_) {}
}

async function loadScreensForTheatre(theatreId) {
    const screenSelect = document.getElementById('showScreenSelect');
    screenSelect.innerHTML = '<option value="" disabled selected>Loading...</option>';
    try {
        const res = await adminApiCall(`/theatres/${theatreId}/screens`);
        if (!res) return;
        screenSelect.innerHTML = '<option value="" disabled selected>Select Screen</option>';
        res.data.forEach(s => {
            screenSelect.innerHTML += `<option value="${s.id}">${s.name} (${s.totalSeats} seats)</option>`;
        });
    } catch (_) {}
}

// --- 4. SHOW SCHEDULER ---
async function loadShows() {
    try {
        const res = await adminApiCall('/shows');
        if (!res) return;
        const tbody = document.getElementById('showsTableBody');
        tbody.innerHTML = '';

        res.data.forEach(s => {
            const dateStr = new Date(s.startTime).toLocaleString();
            tbody.innerHTML += `
                <tr>
                    <td>#${s.id}</td>
                    <td><strong>${s.movieTitle}</strong></td>
                    <td>${s.theatreName} - ${s.screenName}</td>
                    <td>${dateStr}</td>
                    <td>₹${s.price} (${s.format})</td>
                    <td>
                        <button class="btn-danger-sm" onclick="deleteShow(${s.id})">Cancel</button>
                    </td>
                </tr>
            `;
        });
    } catch (_) {}
}

document.getElementById('addShowForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    await withSubmitGuard(e.currentTarget, async () => {
        // Field names must match the backend ShowRequest record exactly:
        // basePrice (not price), language + hasCaptions are required.
        const payload = {
            screenId: parseInt(document.getElementById('showScreenSelect').value),
            movieId: parseInt(document.getElementById('showMovieSelect').value),
            startTime: document.getElementById('showStartTime').value,
            basePrice: parseFloat(document.getElementById('showPrice').value),
            format: document.getElementById('showFormat').value,
            language: document.getElementById('showLanguage').value,
            hasCaptions: document.getElementById('showCaptions').checked
        };

        try {
            await adminApiCall('/shows', 'POST', payload);
            showAlert('Show scheduled successfully!', 'success');
            document.getElementById('addShowForm').reset();
            loadShows();
        } catch (_) {}
    });
});

async function deleteShow(id) {
    if (!confirm('Cancel this scheduled show?')) return;
    try {
        await adminApiCall(`/shows/${id}`, 'DELETE');
        showAlert('Show cancelled.', 'success');
        loadShows();
    } catch (_) {}
}

// Global State for current Screen being modified
let currentEditingScreenId = null;
let currentGridState = []; // Matrix representing seats (1 = Seat, 0 = Pathway)

// 1. Open Modal and Reset State
function openSeatModal(screenId) {
    currentEditingScreenId = screenId;
    document.getElementById('seatModal').classList.remove('hidden');
    generateGrid();
}

function closeSeatModal() {
    document.getElementById('seatModal').classList.add('hidden');
    currentEditingScreenId = null;
}

// 2. Generate Interactive Grid Canvas
function generateGrid() {
    const rows = parseInt(document.getElementById('designerRows').value) || 6;
    const cols = parseInt(document.getElementById('designerCols').value) || 10;
    const canvas = document.getElementById('gridCanvas');

    canvas.style.gridTemplateColumns = `repeat(${cols}, 32px)`;
    canvas.innerHTML = '';
    
    currentGridState = [];

    for (let r = 0; r < rows; r++) {
        let rowArr = [];

        for (let c = 0; c < cols; c++) {
            rowArr.push(1); // 1 means Active Seat by default

            const cell = document.createElement('div');
            cell.className = 'seat-cell active';
            cell.dataset.row = r;
            cell.dataset.col = c;

            // Toggle seat vs pathway on click
            cell.onclick = () => toggleSeatType(cell, r, c);
            canvas.appendChild(cell);
        }
        currentGridState.push(rowArr);
        relabelRow(r); // assign A1, A2, ... to active cells only
    }
}

// Re-number a single row so that only ACTIVE seats get sequential labels.
// Pathways are skipped, so "A5 [pathway] A6" instead of "A5 [pathway] A8".
function relabelRow(row) {
    const rowLabel = String.fromCharCode(65 + row); // A, B, C...
    const canvas = document.getElementById('gridCanvas');
    let seatNo = 0;
    currentGridState[row].forEach((val, col) => {
        const cell = canvas.querySelector(`.seat-cell[data-row="${row}"][data-col="${col}"]`);
        if (!cell) return;
        if (val === 1) {
            seatNo++;
            cell.className = 'seat-cell active';
            cell.innerText = `${rowLabel}${seatNo}`;
        } else {
            cell.className = 'seat-cell pathway';
            cell.innerText = '';
        }
    });
}

// 3. Toggle Seat Type (Seat vs Pathway), then renumber the whole row
function toggleSeatType(cell, row, col) {
    currentGridState[row][col] = currentGridState[row][col] === 1 ? 0 : 1;
    relabelRow(row);
}

// 4. Save Layout Schema to Backend API
async function saveSeatLayout() {
    if (!currentEditingScreenId) return;

    const layoutPayload = {
        rows: parseInt(document.getElementById('designerRows').value),
        cols: parseInt(document.getElementById('designerCols').value),
        matrix: currentGridState
    };

    try {
        await adminApiCall(`/screens/${currentEditingScreenId}/layout`, 'PUT', layoutPayload);
        showAlert('Seat layout and pathways updated successfully!', 'success');
        closeSeatModal();
        loadTheatres(); // Refresh theatre screen views
    } catch (err) {
        // Handled globally by adminApiCall
    }
}