# Movie Booking System — Handoff Document

**Read this entire file before writing any code.** It documents conventions and invariants that are not obvious from the source. Several were discovered by debugging real failures in this codebase; breaking them silently reintroduces bugs that took considerable effort to find.

---

## 1. Project overview

A production-quality mock of PVR's cinema ticket booking system.

| | |
|---|---|
| Backend | Spring Boot 3.4.3, Java 21, Spring Security 6.4.3, Spring Data JPA |
| Database | MySQL, schema `movie_booking_system` |
| Frontend | **Vanilla HTML/CSS/JS. No framework, no build step, no npm.** Served as static resources by Spring Boot |
| Auth | JWT access + refresh tokens, with email OTP verification on every sensitive action |
| Email | Gmail SMTP (app password already configured) |
| Payment | Razorpay test mode — **not yet built** |
| IDE | Spring Tool Suite on Windows |

Three actor roles: `USER`, `ADMIN`, `THEATRE_OWNER`.

An **admin** is responsible for the whole application. A **theatre owner** is scoped to exactly one theatre. Both can schedule shows and view analytics; the owner only ever for their own theatre.

---

## 2. The owner's working style — follow this

These are explicit instructions from the project owner. They matter more than speed.

1. **One module at a time, finished completely, then move on.** Do not work several modules in parallel.
2. **Every change must be additive.** New features must never break existing mechanisms. This is a stated architectural requirement, not a preference.
3. **Features get their own dedicated pages**, not modal overlays bolted onto a nav bar. Login has its own page, for example.
4. **Discuss the plan before writing code** when the change is non-trivial. The owner prefers to agree an approach first.
5. **Consistency across the admin and owner portals is required.** If a capability exists in one, it should exist in the other, styled the same way.

---

## 3. Where the project stands

### Complete and working

- **Authentication** — register, login, forgot password, reset password, account deletion, all with email OTP. Refresh tokens, logout, logout-all.
- **Admin portal** — full CRUD for cities, movies, theatres, screens, shows. Theatre-owner assignment.
- **Owner portal** — at feature parity with admin for everything within the owner's own theatre.
- **Seat tiers and seat layouts** — per-screen pricing tiers (e.g. BUDGET / PREMIUM / DIAMOND) and a drag-to-paint seat grid designer with pathways. Present in both portals.
- **Per-show tier pricing** — each show prices each of its screen's tiers.
- **Customer journey** — city selection, movie grid, movie detail, date strip, showtimes with availability colouring, seat-quantity gate, tiered seat map, 10-minute seat hold with countdown.
- **Soft deletes** across the catalog with audit timestamps.

### Deliberately incomplete

**Bookings stop at `PENDING_PAYMENT` and expire after 10 minutes.** This is a decision by the project owner, not an oversight. There is no confirm endpoint and no mock payment — the booking flow legitimately ends at the hold until Razorpay is integrated. Do not add a fake "confirm" to make it look finished unless asked.

---

## 4. Environment and build

Network access and Maven may be unavailable in an AI sandbox. **Assume you cannot compile.** Therefore:

- Verify all JavaScript with `node --check <file>` before delivering. This catches the unbalanced-brace class of error that has broken this project before.
- Check Java brace/paren balance mechanically. When stripping strings and comments to do so, **strip comments first** — otherwise an apostrophe inside a comment (`owner's theatre`) is parsed as a string delimiter and swallows braces, producing false positives.
- Cross-check that every `onclick`/`onchange` handler in the HTML has a matching function in the corresponding JS file. A misplaced handler attribute has caused a silent failure here before (see §9).
- State clearly to the owner what you verified and what you could not.

### Database migrations

`spring.jpa.hibernate.ddl-auto=update`. There is **no Flyway or Liquibase**. Migrations are hand-written SQL files at the project root, run manually before startup:

| File | Status |
|---|---|
| `MIGRATION.sql` | Applied — soft-delete columns on theatres, screens, shows |
| `MIGRATION-PHASE3.sql` | Applied — `seat_tiers`, `screen_seats`, `show_tier_prices` |
| `MIGRATION-PHASE4.sql` | Applied, but **section 3 failed** with MySQL error 1093 |
| `MIGRATION-PHASE4-FIX.sql` | Supersedes that failed section |

**Rules for writing new migrations:**

- Hibernate creates *new* tables safely. Hand-write the SQL when *altering populated tables*, because Hibernate issues `ADD COLUMN ... NOT NULL` with no `DEFAULT`, which either fails or backfills zero-dates that then break `LocalDateTime` conversion.
- Always add `DEFAULT` clauses and always backfill.
- **`NULL = FALSE` evaluates to `NULL` in SQL, not true.** A row with `is_deleted IS NULL` is invisible to every `findByIsDeletedFalse` query. This already caused a real "my 12 theatres disappeared" incident. Always include `UPDATE ... SET is_deleted = 0 WHERE is_deleted IS NULL;` and a verification `SELECT` that counts NULLs.
- **MySQL forbids referencing the target table of a `DELETE`/`UPDATE` in a subquery of the same statement** (error 1093). Use a temporary table. This is exactly what broke `MIGRATION-PHASE4.sql`.
- Include a verification `SELECT` at the end of every script so the owner can confirm success.

---

## 5. Invariants — do not break these

### 5.1 Price snapshots are immutable

`show_seats.price` and `show_seats.tier_name` are written **once**, when a show's seat map is first materialized, by `BookingService.buildSeatsFromGrid`.

**Never compute revenue by joining back to `seat_tiers` or `show_tier_prices`.** If you do, every historical revenue figure silently changes the moment someone edits a price. The snapshot columns exist specifically to prevent this. Revenue for a booking is `SUM(show_seats.price WHERE booking_id = ?)`.

This is the single most important rule for the analytics module.

### 5.2 Soft deletes are project-wide

These entities extend `BaseEntity`, which supplies `id`, `createdAt`, `updatedAt`, `isDeleted`:

`City`, `Movie`, `Theatre`, `Screen`, `Show`, `SeatTier`, `ScreenSeat`, `ShowTierPrice`, `User`, `Booking`, `ShowSeat`, `EmailOtp`, `RefreshToken`, `AuthLog`

**Every query must filter `isDeleted = false`.** Never use `findAll()`, `findById()`, `deleteById()`, or `existsById()` on these. Use the `...AndIsDeletedFalse` variants. Deletion means `setIsDeleted(true)` and save.

A missed filter here already caused soft-deleted cities and movies to remain visible to customers.

### 5.3 Delete operations must guard foreign keys

`Show → Screen → Theatre → City` is a hard non-nullable FK chain, and bookings hang off shows. Hard deletion destroys paid booking records and the audit trail the spec requires.

Existing guards, which set the pattern to follow:

- Deleting a **theatre** or **screen** is refused while future shows exist
- Deleting a **movie** is refused while future shows are scheduled
- Deleting a **city** is refused while active theatres remain
- Deleting a **tier** is refused while seats still reference it
- Deleting a theatre cascades a *soft* delete to its screens

### 5.4 `open-in-view` is disabled

`spring.jpa.open-in-view=false` in `application.properties`. **Never return a JPA entity from a controller.** Lazy associations will throw `LazyInitializationException` during serialization. Always map to a DTO record *inside* the `@Transactional` service method.

This flag is disabled deliberately: with it enabled, combined with synchronous SMTP, the app leaked its entire HikariCP connection pool (`total=10, active=10, idle=0`) and hung for 30 seconds at a time.

### 5.5 Seat maps materialize lazily, then lock

`show_seats` rows are created the first time anyone opens a show's seat map, not when the show is scheduled.

Consequence: **once materialized, a screen's layout cannot be changed** while future materialized shows exist. `SeatConfigService.assertLayoutEditable()` enforces this and the designer greys out with an explanatory banner. This was an explicit product decision by the owner — do not relax it into "allow the edit and let old shows keep the old map," because that fails silently.

A show that is scheduled but never viewed has no seats yet and does **not** block layout edits.

### 5.6 Errors must be visible

`GlobalExceptionHandler` logs every exception. `NoResourceFoundException` is handled separately as a 404 at debug level so a missing favicon does not spam error logs.

**Never write an empty `catch` block.** There were sixteen `} catch (_) {}` blocks in `admin.js` that silently swallowed a `TypeError`, making the movie library appear permanently empty while every API call returned 200. All were replaced with `console.error` plus a user-facing alert. Do not reintroduce them.

### 5.7 Screen capacity is derived, never typed

`Screen.totalSeats` is computed from the saved seat layout (count of `SEAT` cells). There is no capacity input anywhere in either portal, and `updateScreen` **refuses** to change capacity once a layout exists. Do not add a capacity field back.

---

## 6. Architecture conventions

### 6.1 Shared services with `restrictToTheatreId`

Admin and owner logic is shared, not duplicated. Three services in `com.moviebooking.catalog.service`:

- `ScreenManagementService` — screen rename, soft delete, legacy layout JSON
- `SeatConfigService` — seat tiers, seat grid, per-seat tier assignment
- `ShowPricingService` — per-show tier pricing and price resolution

Each mutating method takes `Long restrictToTheatreId`:

- `null` → admin, unrestricted
- non-null → theatre owner, may only touch screens in that theatre

`AdminService` passes `null`. `OwnerService` passes `currentOwnersTheatre().getId()`.

**Extend this pattern for any new shared capability.** Duplicating logic into both services is how the two portals drifted apart originally — the owner portal never received the seat designer for months.

**Security detail:** when the theatre does not match, these services throw `ResourceNotFoundException`, **not** a permission error. This is deliberate, so an owner cannot enumerate which screen IDs exist in other theatres by observing which error comes back. Preserve this.

### 6.2 Owner identity never comes from the client

`OwnerService.currentOwnersTheatre()` resolves the theatre from the JWT principal. **Never accept a theatre ID from the request body or path in owner endpoints.** This is the single choke point that prevents horizontal privilege escalation.

### 6.3 HQL string concatenation — the space trap

`@Query` annotations use string concatenation. A missing space at a line join produces `CURRENT_TIMESTAMPAND`, which fails at application startup with `BadJpqlGrammarException`. This has happened here.

**Always put the space at the *start* of each continuation line**, never at the end of the previous one — a missing leading space is visible, a missing trailing space is not:

```java
@Query("SELECT DISTINCT s.movie FROM Show s"
     + " WHERE s.screen.theatre.city.id = :cityId"
     + " AND s.isDeleted = false")
```

`ORDER BY` must remain the last clause. Spring validates every `@Query` at startup, so these fail fast — the message contains the fully assembled query in `Bad HQL grammar [...]`, which shows the defect directly.

### 6.4 Response envelope

Everything returns `ApiResponse<T>` with `success`, `message`, `data`. Errors return `ErrorResponse` with `success`, `message`, `errors`.

**Known inconsistency worth fixing:** `handleResourceNotFound` returns `ApiResponse` while other handlers return `ErrorResponse`, so a 404 body has a different shape from a 400. The frontend papers over it with `result.message || result.error`. Standardise on `ErrorResponse` for all failures.

---

## 7. Frontend conventions

**No framework, no build step.** Plain `fetch`, plain DOM.

| File | Purpose |
|---|---|
| `static/index.html` + `css/catalog.css` + `js/catalog.js` | Customer journey |
| `static/admin.html` + `admin.css` + `admin.js` | Admin portal |
| `static/owner.html` + `owner.js` | Owner portal (**reuses `admin.css`**) |
| `static/auth.html` + `auth.css` + `auth.js` | Login and registration |

### 7.1 Use the real CSS classes

`admin.css` defines: `.admin-card`, `.section-title`, `.subtitle`, `.form-group`, `.form-row`, `.grid-layout`, `.data-table`, `.table-wrapper`, `.divider`, `.btn`, `.btn-primary`, `.btn-secondary`, `.btn-sm`, `.btn-danger-sm`, `.designer-controls`, `.grid-canvas`, `.seat-cell`, `.modal`, `.nav-tab`, `.tab-content`, `.hidden`.

There is **no `.card` or `.card-title`.** Using them produced completely unstyled panels in the Maintenance tab — a real reported bug. Check `admin.css` before inventing a class name.

### 7.2 Append new JS functions at the end of the file

Function declarations hoist, so position is irrelevant to behaviour. Appending cannot clobber anything. An unclosed brace in `loadMovies()` once swallowed every function defined after it, producing `ReferenceError: loadTheatres is not defined` while the file still parsed.

### 7.3 Build rows with `createElement`, not `innerHTML +=`

The Maintenance tab and the customer showtime chips already do this. It avoids XSS and the quoting bugs that `onclick="fn('${name}')"` produces when a name contains an apostrophe — addresses very often do.

**Look up values from a cache by ID rather than interpolating them into `onclick` attributes.** `admin.js` uses `window.__theatreCache`, `__movieCache`, `__cityCache`, set during render.

### 7.4 Enum values must match the backend exactly

- `AudioLanguage`: `ENGLISH, TAMIL, HINDI, TELUGU, KANNADA, MALAYALAM`
- `MovieFormat`: `TWO_D, THREE_D, IMAX_2D, IMAX_3D, FOUR_DX` — **the constant is `TWO_D`, not `2D`.** `getValue()` returns the display string `"2D"`
- `CbfcRating`: `U, UA, A, S`
- `SeatType`: `SEAT, PATHWAY, BLOCKED`
- `SeatStatus`: `AVAILABLE, HELD, BOOKED`
- `BookingStatus`: `PENDING_PAYMENT, CONFIRMED, CANCELLED, EXPIRED`

---

## 8. Business rules already implemented

| Rule | Where |
|---|---|
| Max 10 seats per booking | `BookingService.MAX_SEATS_PER_BOOKING` |
| 10-minute seat hold | `BookingService.HOLD_MINUTES` |
| Holds self-heal on expiry | `expireStaleHolds()`, called opportunistically plus a scheduled sweep in `BookingMaintenanceScheduler` |
| Seat holding is all-or-nothing | `holdSeats()` uses `findForUpdate` (pessimistic lock) |
| 100% non-refundable notice shown before payment | `catalog.js` hold confirmation |
| Seat quantity chosen before the map renders, and cannot be skipped | `openSeatCountModal()` in `catalog.js` |
| Seat numbering skips pathways | `SeatConfigService.replaceLayout()` |
| Booking total sums per-seat prices, never `basePrice × count` | `holdSeats()` |
| Show list defaults to today and future | `showsForScope()` in both services |
| Cannot hold seats for a show that already started | `holdSeats()` |

---

## 9. Bugs already fixed — do not reintroduce

Each of these was a real reported failure. They are listed because the failure mode was non-obvious.

1. **`Movie` had no `availableLanguages` field** but `admin.js` called `.join()` on it. `TypeError` inside an empty catch left the movie table permanently blank while every request returned 200.
2. **Connection pool leak** — `open-in-view=true` plus SMTP with no timeout exhausted HikariCP. Fixed with `open-in-view=false`, `mail.smtp.timeout`, and `leak-detection-threshold`.
3. **`onchange` placed on a `<label>`** instead of the `<select>`. Labels do not fire change events, so the admin show form's screen dropdown was permanently empty.
4. **Duplicate theatres** — a retry-on-any-error block in `addTheatreForm` re-POSTed with a different payload shape, creating two theatres when the first request had actually succeeded.
5. **`layoutJson` was written but never read.** `BookingService` used a hardcoded `SEATS_PER_ROW = 10`, so custom layouts had no effect on booking. Superseded by `screen_seats`.
6. **The layout designer reset to a blank 6×10 grid on open** and then overwrote the stored layout on save, so layouts appeared not to persist.
7. **Countdown timer computed `seats × flatPrice`**, giving a wrong total for mixed-tier baskets.
8. **`CatalogService` used `findAll` and `existsById`**, exposing soft-deleted cities and movies to customers.

---

## 10. Current API surface

### Auth (`/auth/**`, public)
`register`, `verify-registration-otp`, `resend-registration-otp`, `login`, `verify-login-otp`, `refresh-token`, `logout`, `logout-all`, `forgot-password`, `reset-password`, `request-account-deletion`, `delete-account`

### Catalog (`/catalog/**`, public)
`GET /cities`, `GET /movies?cityId=`, `GET /movies/{id}?cityId=`, `GET /movies/{id}/shows?cityId=&date=`, `GET /movies/{id}/dates?cityId=&days=`

### Booking (`/api/booking/**`, authenticated)
`GET /shows/{showId}/seats`, `POST /hold`, `GET /{bookingId}`, `POST /{bookingId}/cancel`

### Admin (`/api/admin/**`, `hasRole('ADMIN')`)
Cities, movies, theatres, screens, shows — full CRUD. Owner assignment. Seat tiers, seat grid, per-seat tier assignment, show prices. `GET /shows?scope=upcoming|past|all`.

### Owner (`/api/owner/**`, `hasAnyRole('ADMIN','THEATRE_OWNER')`)
Same as admin but scoped to the owner's theatre. No city/movie/theatre creation.

---

## 11. What remains to be built

### 11.1 Gaps in "finished" modules — address these first

These are small and unblock everything after them.

- **No booking visibility anywhere.** A customer holds seats and then has no way to see the booking. There is no list endpoint and no "My Bookings" page. Admins and owners have no booking or transaction log view, which the spec explicitly requires for audit. **Build this before payment** — it makes the tiered pricing work verifiable without opening MySQL, and it creates the read models analytics will aggregate over.
- **Shows cannot be edited.** No `PUT /shows/{id}`; fixing a start time means cancel and recreate.
- **Seat reservation at scheduling is missing.** The spec says owners and admins "could reserve the seats at the starting itself." Never built.
- **Debug endpoints are live.** `HealthController` exposes `/test-error`, `/encode`, `/jwt-test`, `/secure-test`, `/me`. `/health` is `permitAll`. Remove or secure before anything resembling production.

### 11.2 Payment — Razorpay test mode

Routine mechanics; two things are easy to get dangerously wrong.

**Verify server-side.** Server creates the order and returns only the order ID and public key. The browser opens Checkout. On success the client posts back `payment_id`, `order_id`, `signature`, and **the server verifies the HMAC-SHA256 signature with the secret key** before confirming. A client-reported success means nothing.

**The webhook is authoritative, not the browser callback.** If a user pays then closes the tab, the callback never fires but the money moved — you would have paid customers with expired bookings. Implement both paths converging on one idempotent confirm, protected by a unique constraint on `razorpay_payment_id` so a webhook and callback arriving together cannot double-confirm.

**Unresolved design question — ask the owner.** What happens when the 10-minute hold expires while the user is on the payment screen? With a 100% non-refundable policy, taking the money and apologising is not acceptable. Options: extend the hold when the order is created (e.g. to 15 minutes), or re-validate and refuse to open Checkout if the hold lapsed. Recommendation is both, but the owner must decide.

Other requirements: UUID transaction ID (already generated at hold time in `Booking.transactionId`), transaction logs visible to admins and owners, non-refundable policy displayed before payment (already done).

### 11.3 Notifications

Booking confirmation email with payment receipt and ticket details.

**This is also where the real pool-leak fix belongs.** Phase 0 only added SMTP timeouts. Email is still sent synchronously on the request thread from five places in `AuthServiceImpl` (lines ~138, 319, 396, 604, 768). A slow Gmail connection still stalls a web thread.

Recommendation: `@Async` with a dedicated executor for OTPs (a lost OTP is just a retry), and an `email_outbox` table with a scheduled sender for booking receipts (a lost receipt is a support ticket, and the outbox survives restarts and gives retries).

### 11.4 Analytics

Admin sees the whole system; owner sees only their theatre, reusing the `restrictToTheatreId` pattern so scoping lives in one place.

- Revenue, tickets sold, occupancy, per-movie and per-show breakdowns
- Filters composing over date range, movie, theatre, screen, city, format, language
- **Use JPQL/native aggregation queries.** Never load entities and sum in Java — it will not survive real data volume.
- **Revenue must come from `ShowSeat.price` snapshots.** See §5.1. This is the rule most likely to be broken by someone unfamiliar with why that column exists.

### 11.5 Hardening

- **XSS** — list renders in `admin.js` and `owner.js` still use `innerHTML +=` with raw user data. Propagate the `createElement`/`textContent` pattern already used in the Maintenance tab.
- **Replace `prompt()` dialogs** for editing theatres, screens, movies, cities and tiers with proper forms. These were stopgaps to verify endpoints.
- **Adopt Flyway**, set `ddl-auto=validate`. Four migrations have been hand-run with no record of which were applied.
- **Rotate and externalise secrets.** `application.properties` has env-var placeholders (`${DB_PASSWORD:...}`, `${MAIL_APP_PASSWORD:...}`, `${JWT_SECRET:...}`) but the real values remain as defaults and have been distributed in several archives. The Gmail app password and JWT secret should be rotated.
- **Standardise the error response shape.** See §6.4.
- **There are zero tests.** The highest-value one by far is concurrent booking against the 10-minute hold — the hardest thing to verify by clicking.

### 11.6 Undefined scope — must be settled with the owner

**Admin responsibilities were never pinned down.** The owner deferred this discussion early and it is now the main undefined area. Specifically: can an admin refund or override a booking? Reassign a theatre owner? Edit or cancel another owner's shows? View another owner's analytics?

Both the analytics module and the audit log depend on knowing where this line sits. Settle it before building either.

---

## 12. Suggested sequence

1. **Booking visibility** — My Bookings, admin/owner booking and transaction logs. Plus `PUT /shows/{id}` and seat reservation at scheduling, which are small and fit naturally here.
2. **Payment** — Razorpay, after resolving the hold-expiry question.
3. **Notifications** — needs confirmed bookings to exist.
4. **Analytics** — needs money in the system to be meaningful.
5. **Hardening.**

Each step should leave the application in a working state, per §2.

---

## 13. First actions for the next assistant

1. Read this document fully.
2. Read `application.properties`, `BaseEntity`, `SeatConfigService`, `ShowPricingService`, and `BookingService` — these carry the conventions everything else follows.
3. Confirm the app boots cleanly and that `MIGRATION-PHASE4-FIX.sql` has been applied.
4. Ask the owner the open questions in §11.2 and §11.6 before building anything that depends on them.
5. Propose a plan and get agreement before writing code.
